# Validação — 13/11/2026

## Verificado localmente

- Checagem de tipos TypeScript sem erros; 65 testes de regressão aprovados (incluindo os da prévia arquivada).
- Componentes de autenticação testados com React Test Renderer e API simulada: validação de cadastro, WhatsApp, senhas iguais, credenciais incorretas, confirmação por código, recuperação e encerramento da sessão temporária.
- PostgreSQL embutido (PGlite): esquema/migrações repetíveis, dados preservados, contatos privados por usuário, atualização atômica do perfil, propriedade dos anúncios e regras de Storage. Auth e Storage são simulados nos contratos SQL.
- Repositório: falhas de upload, desfazimento de uploads confirmados, preservação quando há dúvida sobre commit, contatos opcionais e repetição sem duplicar o ID.
- Regressões de cópia, contatos e prévia antiga arquivada. A prévia de teste aguarda o armazenamento inicializar, em vez de depender de um atraso fixo.
- Exportação dos bundles web, Android e iOS pelo Expo/Metro.
- Perfil EAS `apk`, configuração nativa, pacote Android e ícones. Verificação exercitada com configuração válida, ausente, modo demo e chave administrativa: os três últimos casos bloquearam a compilação.

## Verificado no Supabase hospedado

- Projeto ativo na região São Paulo, com criação cotada a US$ 0/mês.
- Migração `20261113125037_create_conectasolidario` instalada; histórico local espelha a migração do servidor.
- Quatro tabelas protegidas por RLS. A função interna do cadastro fica no esquema privado e não pode ser executada diretamente pelos clientes.
- Teste transacional real: criação de perfis pelo gatilho do Auth, salvamento do cadastro e anúncio, rejeição de WhatsApp inválido com atualização atômica, isolamento dos contatos e bloqueio de edição por outra conta. O teste foi desfeito por rollback; a base terminou sem perfis ou anúncios sintéticos.
- Bucket `donation-photos`: JPEG, até 5 MB por foto, com regras de propriedade.
- Auth HTTP respondeu 200: e-mail habilitado, cadastro habilitado e confirmação de e-mail mantida.
- Data API com chave publicável e sem sessão respondeu 401 para anúncios, conforme esperado.
- Auditorias de segurança e saúde sem avisos. A auditoria de desempenho informou dois índices ainda sem uso, coerentes com uma base nova e vazia; os índices foram mantidos. [Referência do aviso](https://supabase.com/docs/guides/database/database-linter?lint=0005_unused_index).

## Ainda falta concluir

SMTP e modelos por código precisam ser configurados antes de liberar cadastro e recuperação para os usuários. O provedor padrão não oferece personalização de modelos em novos projetos Free. Não foi feito envio de e-mail ou teste de confirmação/recuperação com destinatário real.

A conta Expo ainda não está vinculada. Não há chave de assinatura gerada ou APK assinado. Exportar o bundle Android não equivale a compilar o APK com Gradle. A instalação desta versão real e a sincronização em dois aparelhos físicos serão conferidas após a geração do APK. O teste anterior no celular foi da demonstração.
