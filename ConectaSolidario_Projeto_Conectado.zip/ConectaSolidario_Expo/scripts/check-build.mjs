import process from 'node:process';
import {existsSync,readFileSync} from 'node:fs';
if(existsSync('.env'))process.loadEnvFile('.env');
const errors=[];
if(process.env.EXPO_PUBLIC_BACKEND==='demo')errors.push('O APK deve usar o backend real. Defina EXPO_PUBLIC_BACKEND=supabase.');
try{const url=new URL(process.env.EXPO_PUBLIC_SUPABASE_URL||'');if(url.protocol!=='https:'||url.pathname!=='/'||url.search||url.hash)throw new Error();}catch{errors.push('Preencha EXPO_PUBLIC_SUPABASE_URL com a URL HTTPS do projeto.');}
if(!/^sb_publishable_[A-Za-z0-9_-]+$/.test(process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY||''))errors.push('Preencha EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY com a chave publicável.');
const eas=JSON.parse(readFileSync('eas.json','utf8'));
if(eas.build.apk.android.buildType!=='apk'||eas.build.apk.distribution!=='internal')errors.push('O perfil apk precisa gerar um APK de distribuição interna.');
if(errors.length){console.error(errors.join('\n'));process.exitCode=1;}else console.log('Configuração do backend real e do APK validada.');
