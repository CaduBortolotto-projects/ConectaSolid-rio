# Gerar e instalar o APK

O perfil `apk` de `eas.json` gera um instalador Android com os recursos incorporados. Ele abre como aplicativo próprio; internet continua necessária para login e sincronização.

**Antes:** confira o envio de e-mails em `GUIA_CONEXAO.md`. O banco e a configuração pública já estão prontos; ainda não há APK nem projeto Expo vinculado. Use os valores reais do `.env` incluído no ambiente de compilação da Expo.

## Pelo navegador no computador da empresa

Use [GitHub Codespaces](https://docs.github.com/en/codespaces/developing-in-a-codespace/creating-a-codespace-for-a-repository) para executar as ferramentas na nuvem. Confira a cota da sua conta pessoal.

1. Crie um repositório privado no GitHub com README, para ter uma primeira versão.
2. Abra **Code → Codespaces → Create codespace** e use o editor no navegador.
3. Envie o ZIP pelo explorador do editor, extraia no terminal do Codespaces e entre em `ConectaSolidario_Expo`.
4. Execute os comandos abaixo **no terminal online**, dentro da pasta com `package.json` e `eas.json`:

```sh
npm ci
npx eas-cli@latest login
npx eas-cli@latest init
```

Entre na sua conta Expo. Caso ainda não tenha, crie a conta no site da Expo. No `init`, selecione a sua conta e crie ou vincule o ConectaSolidário. Preserve o identificador real gravado em `app.json` para as próximas versões.

## Variáveis da compilação

No projeto Expo, abra **Environment variables** e configure no ambiente **production**:

| Nome | Valor |
|---|---|
| `EXPO_PUBLIC_SUPABASE_URL` | URL real da API do projeto Supabase |
| `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Chave publicável ativa do mesmo projeto |

Use visibilidade `plaintext` ou `sensitive`, não `secret`: são valores públicos do cliente. O backend `supabase` já está definido no perfil. Não inclua chaves administrativas.

Um `.env` local não é enviado automaticamente ao servidor de compilação. Veja [variáveis de ambiente](https://docs.expo.dev/eas/environment-variables/).

## Compilar e instalar

No terminal do Codespaces:

```sh
npx eas-cli@latest build --platform android --profile apk
```

Se a Expo oferecer gerar a chave de assinatura Android, use a chave gerenciada na sua conta e preserve-a para as próximas versões. Confira os limites do plano antes de iniciar. A verificação do projeto interrompe a compilação se faltar o backend real.

Ao concluir, abra a página do resultado da Expo no Android e baixe o `.apk`. Autorize a instalação pelo navegador quando o Android solicitar, instale e abra o ConectaSolidário.

Cadastre uma conta, confirme o código do e-mail e valide a sincronização entre dois aparelhos antes de compartilhar o instalador. Atualizações devem manter `br.conectasolidario.app`, a chave de assinatura e um `android.versionCode` maior em `app.json`.

Referências: [primeira compilação](https://docs.expo.dev/build/setup/), [APK](https://docs.expo.dev/build-reference/apk/), [distribuição interna](https://docs.expo.dev/build/internal-distribution/).
