# Configurar contas e banco reais

## 1. Base já criada e conectada

Projeto: `ConectaSolidario`. Região: São Paulo (`sa-east-1`). Referência: `osqyzdsptoroytakbhnh`. A migração `20261113125037_create_conectasolidario` já foi aplicada, criando as quatro tabelas, o bucket e as políticas. O arquivo correspondente está em `supabase/migrations/`; os scripts da versão anterior estão em `supabase/legacy_migrations/`.

Não é necessário criar outra base ou reaplicar o esquema neste projeto. Para instalações futuras independentes, `supabase/schema.sql` contém o esquema completo. A referência do projeto está em `supabase/project.json`.

| Estrutura | Finalidade |
|---|---|
| `profiles` | Nome público e tipo de conta |
| `profile_contacts` | Contatos privados do próprio usuário |
| `donations` | Anúncios e referências das fotos |
| `donation_contacts` | Contatos escolhidos para o anúncio |
| `donation-photos` | Fotos JPEG dos produtos |

As tabelas exigem login. Cada dono altera seus dados e anúncios; outras contas não leem os contatos privados do perfil. As fotos do produto usam URLs públicas destinadas à divulgação do anúncio.

## 2. Configurar o envio de e-mails

Em Authentication, habilite cadastro por e-mail/senha, confirmação do e-mail e senha mínima de oito caracteres.

O próximo passo é configurar um servidor SMTP com remetente e domínio verificados para enviar mensagens a usuários reais. O SMTP padrão do Supabase limita os destinatários e os envios; ele não atende um cadastro público. A instalação do banco não configura o serviço de e-mail. Neste novo projeto Free, a personalização dos modelos por código depende do SMTP próprio; não é preciso migrar para Pro para usar SMTP próprio.

Nos modelos de e-mail do Supabase:

- **Confirm signup**: cole `supabase/email-templates/confirm-signup.html`.
- **Reset password**: cole `supabase/email-templates/reset-password.html`.

Ambos usam `{{ .Token }}`. A pessoa recebe o código e o digita no app, sem depender de links de retorno. O aplicativo aceita seis a dez dígitos. A validade e os limites de tentativas são controlados pelo Supabase.

Mudança do plano Free: [personalização de e-mails](https://supabase.com/changelog/46599-changes-to-email-template-customisation-on-free-tier).

Referências: [modelos](https://supabase.com/docs/guides/auth/auth-email-templates), [SMTP](https://supabase.com/docs/guides/auth/auth-smtp), [verificação de códigos](https://supabase.com/docs/reference/javascript/auth-verifyotp).

## 3. Preencher a configuração

O `.env` incluído já contém a URL e a chave publicável ativa deste projeto. Nenhuma chave administrativa foi incluída. Para outra instalação, os nomes das variáveis são:

```dotenv
EXPO_PUBLIC_BACKEND=supabase
EXPO_PUBLIC_SUPABASE_URL=https://URL-DO-SEU-PROJETO.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_CHAVE-DO-SEU-PROJETO
```

Os valores do bloco acima são exemplos de formato; use o `.env` que acompanha este projeto para a base já criada. Chaves administrativas `service_role` e `sb_secret_` ficam fora do app. A autorização usa a conta autenticada e as políticas do banco.

Reinicie o Expo depois de alterar as variáveis. Para compilar remotamente, configure os valores também no ambiente `production` da Expo, conforme `GUIA_APK.md`.

## 4. Validar a integração

1. Cadastre um e-mail que você controla e um WhatsApp válido. Confirme o código recebido.
2. Saia, entre com senha e reabra o aplicativo para conferir a sessão persistente.
3. Saia, recupere a senha por código e entre com a nova senha.
4. Edite o perfil e publique um anúncio com duas fotos e os contatos escolhidos.
5. Em outra conta/aparelho, atualize o feed, abra o anúncio e confira os contatos e as fotos.
6. Pelo dono, remova uma foto, edite os opcionais, marque como doado, reative e exclua. A outra conta não deve editar o anúncio nem ler os contatos privados do perfil.

O feed atualiza após alterações, ao voltar ao primeiro plano e por **Atualizar**. Não há publicação offline nem eventos em tempo real nesta versão. Falhas preservam o formulário; quando o resultado de uma gravação for incerto, confira os anúncios antes de tentar novamente.
