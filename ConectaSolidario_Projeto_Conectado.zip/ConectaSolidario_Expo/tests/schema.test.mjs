import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';

test('SQL executa, é repetível e isola anúncios e contatos por proprietário',async t=>{
  const db=new PGlite();
  // PostgreSQL embutido. Auth e Storage são simulados somente nos seus contratos SQL.
  await db.exec(await fs.readFile(new URL('./fixtures/bootstrap.sql',import.meta.url),'utf8'));
  const sql=await fs.readFile(new URL('../supabase/schema.sql',import.meta.url),'utf8');
  await t.test('migração executa duas vezes sem remover dados',async()=>{await db.exec(sql);await db.exec(sql);});
  const a='10000000-0000-4000-8000-000000000001',b='20000000-0000-4000-8000-000000000002';
  const donation='30000000-0000-4000-8000-000000000003',failed='40000000-0000-4000-8000-000000000004',photo='50000000-0000-4000-8000-000000000005';
  await db.query('insert into auth.users(id,raw_user_meta_data) values($1,$2),($3,$4)',[a,{display_name:'Pessoa A'},b,{display_name:'Pessoa B',account_type:'ONG'}]);
  await t.test('instalação atende contas antigas e cadastro cria novos perfis',async()=>assert.equal((await db.query('select count(*)::int n from public.profiles')).rows[0].n,3));
  async function as(id){await db.exec('reset role; set role authenticated;');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]);}
  async function save(id=donation,title='Mesa de escritório',phone='5554999999999',paths=[]){return db.query('select public.save_donation($1::uuid,$2,$3,$4,$5,$6,$7,$8::text[],$9::numeric,$10::numeric)',[id,title,'Móveis','Mesa usada em boas condições.','Caxias do Sul','RS',phone,paths,null,null]);}
  await as(a);await save();
  await t.test('repetir publicação com o mesmo ID não duplica a doação',async()=>{await save();assert.equal((await db.query('select count(*)::int n from public.donations')).rows[0].n,1);});
  await t.test('publicação salva anúncio e contato',async()=>assert.equal((await db.query('select phone from public.donation_contacts')).rows[0].phone,'5554999999999'));
  await t.test('falha no contato desfaz também o anúncio',async()=>{await assert.rejects(save(failed,'Mesa não deve existir','123'));assert.equal((await db.query('select count(*)::int n from public.donations where id=$1',[failed])).rows[0].n,0);});
  await t.test('falha ao editar contato preserva o anúncio anterior',async()=>{await assert.rejects(save(donation,'Título inválido não fica salvo','123'));assert.equal((await db.query('select title from public.donations where id=$1',[donation])).rows[0].title,'Mesa de escritório');});
  await t.test('banco rejeita mais de seis fotos e caminhos de outro dono',async()=>{
    const path=`${a}/${donation}/${photo}.jpg`;await assert.rejects(save(donation,'Mesa de escritório','5554999999999',Array(7).fill(path)));
    await assert.rejects(save(donation,'Mesa de escritório','5554999999999',[`${b}/${donation}/${photo}.jpg`]));
  });
  const path=`${a}/${donation}/${photo}.jpg`;
  await db.query('insert into storage.objects(bucket_id,name) values($1,$2)',['donation-photos',path]);
  await as(b);
  await t.test('outra conta lê doação disponível e acessa contato ao solicitar',async()=>{assert.equal((await db.query('select count(*)::int n from public.donations')).rows[0].n,1);assert.equal((await db.query('select count(*)::int n from public.donation_contacts')).rows[0].n,1);});
  await t.test('outra conta não edita nem exclui anúncio do dono',async()=>{
    assert.equal((await db.query("update public.donations set title='Tentativa de alteração' where id=$1 returning id",[donation])).rows.length,0);
    assert.equal((await db.query('delete from public.donations where id=$1 returning id',[donation])).rows.length,0);
    await assert.rejects(save());
  });
  await t.test('outra conta não altera contatos nem perfil alheio',async()=>{
    assert.equal((await db.query("update public.donation_contacts set phone='5555999999999' where donation_id=$1 returning donation_id",[donation])).rows.length,0);
    assert.equal((await db.query("update public.profiles set display_name='Alterado' where id=$1 returning id",[a])).rows.length,0);
  });
  await t.test('Storage bloqueia envio e exclusão no caminho de outro dono',async()=>{
    await assert.rejects(db.query('insert into storage.objects(bucket_id,name) values($1,$2)',['donation-photos',path]));
    assert.equal((await db.query('delete from storage.objects where name=$1 returning id',[path])).rows.length,0);
  });
  await as(a);await db.query("update public.donations set status='doado' where id=$1",[donation]);await as(b);
  await t.test('anúncio doado e contato deixam de ser visíveis para outros',async()=>{assert.equal((await db.query('select count(*)::int n from public.donations')).rows[0].n,0);assert.equal((await db.query('select count(*)::int n from public.donation_contacts')).rows[0].n,0);});
  await db.exec('reset role; set role anon;');
  await t.test('visitante sem login não lê anúncios nem contatos',async()=>{await assert.rejects(db.query('select * from public.donations'));await assert.rejects(db.query('select * from public.donation_contacts'));await assert.rejects(save());});
  await as(a);
  await t.test('dono exclui anúncio, contato em cascata e fotos',async()=>{
    assert.equal((await db.query('delete from public.donations where id=$1 returning id',[donation])).rows.length,1);
    assert.equal((await db.query('select count(*)::int n from public.donation_contacts')).rows[0].n,0);
    assert.equal((await db.query('delete from storage.objects where name=$1 returning id',[path])).rows.length,1);
  });
  await db.close();
});
