import test from 'node:test';
import assert from 'node:assert/strict';
import { IDBFactory } from 'fake-indexeddb';
import {withPreview,click,fill,login,tick} from './previewHarness.mjs';
function start(w){login(w);click(w,'#tabs button[data-page=new]');fill(w,'pTitle','Mesa para doar');fill(w,'pDesc','Mesa de escritório em boas condições.');fill(w,'pCity','Caxias do Sul');fill(w,'pPhone','(54) 99999-9999');}
async function publish(w){click(w,'#publish');await tick();assert.ok(w.document.querySelector('.detail-title'));}
test('WhatsApp é obrigatório mesmo quando há e-mail e Instagram',()=>withPreview(async w=>{
  start(w);fill(w,'pPhone','');fill(w,'pContactEmail','doador@example.test');fill(w,'pInstagram','@doador_teste');
  assert.equal(w.document.getElementById('productForm').checkValidity(),false);click(w,'#publish');assert.equal(w.document.querySelector('.detail-title'),null);
  fill(w,'pPhone','11');click(w,'#publish');assert.equal(w.document.getElementById('formError').hidden,false);
}));
test('somente WhatsApp já permite publicar e copiar o número',()=>withPreview(async(w,{copied,opened})=>{
  start(w);await publish(w);assert.ok(w.document.querySelector('.contact-card'));
  assert.equal(w.document.querySelector('[data-contact=email]'),null);assert.equal(w.document.querySelector('.instagram-link'),null);
  click(w,'[data-contact=phone]');await tick();assert.deepEqual(copied,['+5554999999999']);assert.deepEqual(opened,[]);
  assert.match(w.document.getElementById('contactFeedback').textContent,/copiado/);
  assert.doesNotMatch(w.document.querySelector('.contact-card').textContent,/demo@conectasolidario/);
}));
test('e-mail é copiado e Instagram é um link de perfil normalizado',()=>withPreview(async(w,{copied})=>{
  start(w);fill(w,'pContactEmail','  Doador@example.test  ');fill(w,'pInstagram','https://instagram.com/Meu.Perfil/?igsh=teste');await publish(w);
  click(w,'[data-contact=email]');await tick();assert.deepEqual(copied,['Doador@example.test']);
  const link=w.document.querySelector('.instagram-link');assert.equal(link.href,'https://www.instagram.com/meu.perfil/');assert.equal(link.target,'_blank');assert.match(link.rel,/noopener/);
  assert.equal(w.document.querySelector('[data-action=whatsapp]'),null);assert.equal(w.document.querySelector('a[href*="wa.me"]'),null);
}));
test('contatos inválidos mantêm o formulário e não publicam',()=>withPreview(async w=>{
  start(w);fill(w,'pContactEmail','email-invalido');click(w,'#publish');assert.match(w.document.getElementById('formError').textContent,/e-mail/);
  fill(w,'pContactEmail','');fill(w,'pInstagram','https://instagram.com.evil.test/perfil');click(w,'#publish');assert.match(w.document.getElementById('formError').textContent,/Instagram/);
  assert.equal(w.document.getElementById('pTitle').value,'Mesa para doar');assert.equal(w.document.querySelector('.detail-title'),null);
}));
test('fallback de cópia funciona quando a API moderna é bloqueada',()=>withPreview(async(w,{copied})=>{
  start(w);await publish(w);click(w,'[data-contact=phone]');await tick();assert.deepEqual(copied,['+5554999999999']);assert.match(w.document.getElementById('contactFeedback').textContent,/copiado/);
},{clipboard:'reject',fallback:true}));
test('falha de cópia seleciona o texto sem informar sucesso falso',()=>withPreview(async(w,{copied})=>{
  start(w);await publish(w);click(w,'[data-contact=phone]');await tick();assert.deepEqual(copied,[]);
  assert.match(w.document.getElementById('contactFeedback').textContent,/texto foi selecionado/);assert.equal(w.document.querySelector('[data-contact=phone]').textContent,'Copiar');assert.match(w.getSelection().toString(),/99999/);
},{clipboard:'reject',fallback:false}));
test('contatos persistem após recarregar e campos opcionais podem ser removidos',async()=>{
  const factory=new IDBFactory();
  await withPreview(async w=>{start(w);fill(w,'pContactEmail','doador@example.test');fill(w,'pInstagram','@perfil_teste');await publish(w);},{factory});
  await withPreview(async w=>{login(w);click(w,'#tabs button[data-page=profile]');click(w,'.mine');assert.equal(w.document.getElementById('contactEmail').textContent,'doador@example.test');click(w,'[data-action=edit-product]');assert.equal(w.document.getElementById('pInstagram').value,'https://www.instagram.com/perfil_teste/');fill(w,'pContactEmail','');fill(w,'pInstagram','');await publish(w);assert.equal(w.document.querySelector('[data-contact=email]'),null);assert.equal(w.document.querySelector('.instagram-link'),null);assert.ok(w.document.querySelector('[data-contact=phone]'));},{factory});
  await withPreview(async w=>{login(w);click(w,'#tabs button[data-page=profile]');click(w,'.mine');assert.equal(w.document.querySelector('[data-contact=email]'),null);assert.equal(w.document.querySelector('.instagram-link'),null);},{factory});
});
