import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
test('migração de contatos preserva dados antigos e permite gravar ou remover opcionais',async()=>{
 const db=new PGlite();try{
  await db.exec(await fs.readFile(new URL('./fixtures/bootstrap.sql',import.meta.url),'utf8'));
  await db.exec(await fs.readFile(new URL('./fixtures/schema_previous.sql',import.meta.url),'utf8'));
  const owner='10000000-0000-4000-8000-000000000001',other='20000000-0000-4000-8000-000000000002',id='30000000-0000-4000-8000-000000000003';
  await db.query('insert into auth.users(id,raw_user_meta_data) values($1,$2),($3,$4)',[owner,{display_name:'Doador Teste'},other,{display_name:'Outra Pessoa'}]);
  await db.exec('set role authenticated;');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[owner]);
  const oldArgs=[id,'Mesa de escritório','Móveis','Mesa usada em boas condições.','Caxias do Sul','RS','5554999999999',[],null,null];
  await db.query('select public.save_donation($1::uuid,$2,$3,$4,$5,$6,$7,$8::text[],$9::numeric,$10::numeric)',oldArgs);
  await db.exec('reset role;');const migration=await fs.readFile(new URL('../supabase/legacy_migrations/20261113_contacts.sql',import.meta.url),'utf8');
  await db.exec(migration);await db.exec(migration);
  assert.deepEqual((await db.query('select phone,email,instagram_url from public.donation_contacts')).rows[0],{phone:'5554999999999',email:null,instagram_url:null});
  assert.equal((await db.query('select title from public.donations')).rows[0].title,'Mesa de escritório');
  await db.exec('set role authenticated;');
  const save='select public.save_donation($1::uuid,$2,$3,$4,$5,$6,$7,$8::text[],$9::numeric,$10::numeric,$11::text,$12::text)';
  await db.query(save,[...oldArgs,'Doador@example.test','https://www.instagram.com/doador_teste/']);
  assert.equal((await db.query('select email from public.donation_contacts')).rows[0].email,'Doador@example.test');
  await assert.rejects(db.query(save,[...oldArgs,'email-invalido',null]));
  await assert.rejects(db.query(save,[...oldArgs,null,'javascript:alert(1)']));
  assert.equal((await db.query('select email from public.donation_contacts')).rows[0].email,'Doador@example.test');
  await db.query("select set_config('request.jwt.claim.sub',$1,false)",[other]);
  assert.equal((await db.query('select email from public.donation_contacts')).rows[0].email,'Doador@example.test');
  assert.equal((await db.query('update public.donation_contacts set email=null where donation_id=$1 returning donation_id',[id])).rows.length,0);
  await db.query("select set_config('request.jwt.claim.sub',$1,false)",[owner]);
  await db.query(save,[...oldArgs,null,null]);
  assert.deepEqual((await db.query('select phone,email,instagram_url from public.donation_contacts')).rows[0],{phone:'5554999999999',email:null,instagram_url:null});
  await assert.rejects(db.query(save,[...oldArgs.slice(0,6),'',...oldArgs.slice(7),null,null]));
 }finally{await db.close();}
});
