import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as domain from '../src/domain.ts';
import * as authRules from '../src/authRules.ts';

const source=fs.readFileSync(new URL('../src/repository.ts',import.meta.url),'utf8');
const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
function fixture(){
  const state={uploaded:[],removed:[],rpcIds:[],rpcArgs:[],paths:[],uploadErrorAt:0,rpcError:null,commitBeforeError:false,cleanupError:null};let sequence=0;
  const bucket={
    async upload(path){state.uploaded.push(path);return {error:state.uploadErrorAt===state.uploaded.length?{message:'Upload falhou'}:null};},
    async remove(paths){state.removed.push(...paths);return {error:state.cleanupError};},
    getPublicUrl(path){return {data:{publicUrl:'https://storage.example.test/'+path}};},
  };
  const api={storage:{from:()=>bucket},from:()=>({select(){return this;},eq(){return this;},async maybeSingle(){return {data:{photo_paths:state.paths},error:null};}}),async rpc(_name,args){state.rpcIds.push(args.p_id);state.rpcArgs.push(args);if(!state.rpcError||state.commitBeforeError)state.paths=[...args.p_photo_paths];return {data:args.p_id,error:state.rpcError};}};
  const imports={
    '@react-native-async-storage/async-storage':{default:{}},'expo-file-system/legacy':{},'react-native':{Platform:{OS:'web'}},
    'expo-crypto':{randomUUID:()=>`50000000-0000-4000-8000-${String(++sequence).padStart(12,'0')}`},
    'base64-arraybuffer':{decode:()=>new ArrayBuffer(1)},'./supabase':{supabase:api,configurationError:''},'./domain':domain,'./authRules':authRules,
  };
  const module={exports:{}};
  vm.runInNewContext(compiled,{module,exports:module.exports,require:name=>{if(!(name in imports))throw new Error('Unexpected import '+name);return imports[name];},fetch:async()=>({ok:true,arrayBuffer:async()=>new ArrayBuffer(10)}),ArrayBuffer,Set,Error,JSON});
  const item={id:'30000000-0000-4000-8000-000000000003',ownerId:'10000000-0000-4000-8000-000000000001',owner:'Teste',title:'Mesa de escritório',category:'Móveis',description:'Mesa usada em boas condições.',city:'Caxias do Sul',state:'RS',phone:'54999999999',photos:[{id:'p1',uri:'blob:foto1'},{id:'p2',uri:'blob:foto2'}],image:'',status:'disponivel',date:'Hoje'};
  return {state,item,repo:module.exports};
}
test('falha no segundo upload limpa somente os arquivos novos e não grava o anúncio',async()=>{
  const {state,item,repo}=fixture();state.uploadErrorAt=2;
  await assert.rejects(repo.saveOnline(item),/Upload falhou/);
  assert.equal(state.rpcIds.length,0);assert.deepEqual(state.removed,[state.uploaded[0]]);
});
test('erro SQL confirmado desfaz os uploads da tentativa',async()=>{
  const {state,item,repo}=fixture();state.rpcError={code:'23514',message:'Dados inválidos'};
  await assert.rejects(repo.saveOnline(item),/Dados inválidos/);assert.deepEqual(state.removed,state.uploaded);
});
test('queda de rede após possível commit preserva as fotos enviadas',async()=>{
  const {state,item,repo}=fixture();state.rpcError={code:'',message:'Failed to fetch'};state.commitBeforeError=true;
  await assert.rejects(repo.saveOnline(item),/antes de confirmar/);assert.equal(state.removed.length,0);assert.equal(state.paths.length,2);
});
test('nova tentativa com mesmo ID atualiza uma única doação e limpa fotos substituídas',async()=>{
  const {state,item,repo}=fixture();state.rpcError={code:'',message:'Failed to fetch'};state.commitBeforeError=true;
  await assert.rejects(repo.saveOnline(item));const firstPaths=[...state.paths];
  state.rpcError=null;const result=await repo.saveOnline(item);
  assert.deepEqual(state.rpcIds,[item.id,item.id]);assert.deepEqual(state.removed,firstPaths);
  assert.equal(result.item.photos.length,2);assert.ok(result.item.photos.every(p=>!firstPaths.includes(p.path)));
  assert.equal(result.item.phone,undefined);
});
test('falha na limpeza não transforma anúncio salvo em publicação perdida',async()=>{
  const {state,item,repo}=fixture();state.paths=['old/photo.jpg'];state.cleanupError={message:'Storage indisponível'};
  const result=await repo.saveOnline(item);assert.equal(result.item.id,item.id);assert.ok(result.warning);assert.equal(state.rpcIds.length,1);
});

test('repositório grava os opcionais normalizados e não os mistura ao feed',async()=>{
  const {state,item,repo}=fixture();item.contactEmail=' Doador@example.test ';item.instagramUrl='@Meu.Perfil';
  const result=await repo.saveOnline(item);
  assert.equal(state.rpcArgs[0].p_email,'Doador@example.test');assert.equal(state.rpcArgs[0].p_instagram_url,'https://www.instagram.com/meu.perfil/');
  assert.equal(result.item.contactEmail,undefined);assert.equal(result.item.instagramUrl,undefined);
});
