import test from 'node:test';
import assert from 'node:assert/strict';
import {withPreview,click,fill,home,login,tick} from './previewHarness.mjs';

test('chave de teste preenchida permite entrar com um clique, sem senha',()=>withPreview(async w=>{
  assert.equal(w.document.getElementById('loginEmail').value,'demo@conectasolidario.test');
  assert.equal(w.document.querySelector('input[type=password]'),null);
  assert.equal(w.document.getElementById('demoLoginForm').checkValidity(),true);
  login(w);
}));
test('segunda alternativa abre cadastro e permite entrar com os dados prontos',()=>withPreview(async w=>{
  click(w,'button[data-page=register]');
  assert.equal(w.document.getElementById('regName').value,'Visitante Demo');
  assert.equal(w.document.getElementById('regEmail').value,'demo@conectasolidario.test');
  click(w,'#demoRegisterForm button[type=submit]');home(w);
}));
test('Enter no campo de acesso abre o feed',()=>withPreview(async w=>{
  w.document.getElementById('loginEmail').dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));home(w);
}));
test('chave com acento da imagem é aceita como identificador local',()=>withPreview(async w=>{
  fill(w,'loginEmail','demonstração@gmail.com');
  assert.equal(w.document.getElementById('demoLoginForm').checkValidity(),true);
  login(w);assert.match(w.document.querySelector('.top').textContent,/demonstração/);
}));
test('cadastro aceita chave fictícia com acento e envio por Enter',()=>withPreview(async w=>{
  click(w,'button[data-page=register]');fill(w,'regName','Carlos Demo');fill(w,'regEmail','demonstração@exemplo.test');
  w.document.getElementById('regEmail').dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));home(w);
}));
test('entrada inválida mostra aviso e permite corrigir sem recarregar',()=>withPreview(async w=>{
  fill(w,'loginEmail','sem-arroba');click(w,'#demoLoginForm button[type=submit]');
  assert.equal(w.document.getElementById('search'),null);assert.equal(w.document.getElementById('formError').hidden,false);
  fill(w,'loginEmail','demo@conectasolidario.test');login(w);
}));
test('depois de entrar, navegação e publicação respondem aos eventos',()=>withPreview(async w=>{
  login(w);click(w,'#tabs button[data-page=new]');
  fill(w,'pTitle','Mesa de demonstração');fill(w,'pDesc','Mesa em boas condições para testar a doação.');fill(w,'pCity','Caxias do Sul');fill(w,'pPhone','54 99999-9999');
  click(w,'#publish');await tick();
  assert.equal(w.document.querySelector('.detail-title')?.textContent,'Mesa de demonstração');
  click(w,'button[data-action=edit-product]');fill(w,'pTitle','Mesa atualizada');click(w,'#publish');await tick();
  assert.equal(w.document.querySelector('.detail-title')?.textContent,'Mesa atualizada');
}));
test('visualizador e saída continuam funcionando sem funções globais',()=>withPreview(async w=>{
  login(w);click(w,'.tile');click(w,'button[data-action=open-viewer]');assert.equal(w.document.getElementById('viewer').open,true);
  click(w,'button[data-action=close-viewer]');assert.equal(w.document.getElementById('viewer').open,false);
  click(w,'button[data-action=back]');click(w,'#tabs button[data-page=profile]');click(w,'button[data-action=logout]');
  assert.equal(w.document.getElementById('loginEmail').value,'demo@conectasolidario.test');login(w);
}));
test('prévia não depende de atributos inline para acionar os controles',()=>withPreview(async w=>{
  assert.equal(w.document.querySelector('[onclick],[onsubmit],[oninput],[onchange]'),null);
  login(w);click(w,'#tabs button[data-page=new]');assert.equal(w.document.querySelector('[onclick],[onsubmit],[oninput],[onchange]'),null);
}));
