-- Verificação transacional: os usuários e anúncios sintéticos são desfeitos.
-- Executar com a conexão administrativa do projeto, nunca dentro do aplicativo.
begin;
do $qa$
declare
  a uuid:=gen_random_uuid(); b uuid:=gen_random_uuid(); donation uuid:=gen_random_uuid();
  n integer; denied boolean;
begin
  insert into auth.users(id,email,raw_user_meta_data)
  values(a,'qa-'||a||'@example.invalid',jsonb_build_object('display_name','Verificação A','contact_phone','5554999999999')),
        (b,'qa-'||b||'@example.invalid',jsonb_build_object('display_name','Verificação B','contact_phone','5554999999998'));
  if not exists(select 1 from public.profile_contacts where user_id=a and phone='5554999999999') then raise exception 'O gatilho do cadastro não salvou o contato.'; end if;

  perform set_config('request.jwt.claim.sub',a::text,true);
  execute 'set local role authenticated';
  perform public.save_profile('Verificação A','Pessoa física','5554999999999','qa@example.invalid',null);
  perform public.save_donation(donation,'Item de verificação','Outros','Anúncio temporário de verificação.','Caxias do Sul','RS','5554999999999',array[]::text[]);
  select count(*) into n from public.profile_contacts;
  if n<>1 then raise exception 'Contatos privados não ficaram isolados.'; end if;
  denied:=false;
  begin
    perform public.save_profile('Nome que não deve persistir','Pessoa física','123',null,null);
  exception when check_violation then denied:=true;
  end;
  if not denied then raise exception 'WhatsApp inválido foi aceito.'; end if;
  if not exists(select 1 from public.profiles where id=a and display_name='Verificação A') then raise exception 'Falha na atualização atômica do perfil.'; end if;

  perform set_config('request.jwt.claim.sub',b::text,true);
  if exists(select 1 from public.profile_contacts where user_id=a) then raise exception 'Outra conta leu contatos privados.'; end if;
  if not exists(select 1 from public.donation_contacts where donation_id=donation) then raise exception 'Contato do anúncio disponível não ficou acessível.'; end if;
  update public.donations set title='Alteração indevida' where id=donation;
  get diagnostics n=row_count;
  if n<>0 then raise exception 'Outra conta alterou o anúncio.'; end if;
  denied:=false;
  begin
    perform public.save_donation(donation,'Tentativa de outra conta','Outros','Tentativa de edição de outro proprietário.','Caxias do Sul','RS','5554999999998',array[]::text[]);
  exception when insufficient_privilege then denied:=true;
  end;
  if not denied then raise exception 'A função permitiu editar anúncio alheio.'; end if;

  perform set_config('request.jwt.claim.sub',a::text,true);
  update public.donations set status='doado' where id=donation;
  perform set_config('request.jwt.claim.sub',b::text,true);
  if exists(select 1 from public.donations where id=donation) or exists(select 1 from public.donation_contacts where donation_id=donation) then raise exception 'Anúncio concluído ficou visível para outra conta.'; end if;
  execute 'reset role';
end;
$qa$;
rollback;
select jsonb_build_object(
  'transactional_checks','passed',
  'tables',(select jsonb_agg(jsonb_build_object('name',c.relname,'rls',c.relrowsecurity,'anonymous_select',has_table_privilege('anon',c.oid,'select'))) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r'),
  'private_trigger_anonymous_execute',has_function_privilege('anon','private.handle_new_user()','execute'),
  'private_trigger_authenticated_execute',has_function_privilege('authenticated','private.handle_new_user()','execute'),
  'profiles_count',(select count(*) from public.profiles),
  'donations_count',(select count(*) from public.donations),
  'bucket',(select jsonb_build_object('id',id,'max_bytes',file_size_limit,'mime_types',allowed_mime_types) from storage.buckets where id='donation-photos')
) as verification;
