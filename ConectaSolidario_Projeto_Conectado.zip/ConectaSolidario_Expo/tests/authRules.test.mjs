import test from 'node:test';
import assert from 'node:assert/strict';
import {accountEmail,accountName,accountPassword,accountCode,accountError} from '../src/authRules.ts';
test('cadastro normaliza e-mail e nome, sem alterar senhas',()=>{
  assert.equal(accountEmail(' Carlos@Example.com '),'carlos@example.com');assert.equal(accountName(' Carlos Bortolotto '),'Carlos Bortolotto');assert.equal(accountPassword(' senha123 ',' senha123 '),' senha123 ');
});
test('cadastro rejeita dados inválidos e confirmação de senha diferente',()=>{
  for(const value of ['sem-arroba','a@b','<a>@example.com','a b@example.com'])assert.throws(()=>accountEmail(value));
  assert.throws(()=>accountName('A'));assert.throws(()=>accountName('a'.repeat(81)));assert.throws(()=>accountPassword('curta'));assert.throws(()=>accountPassword('senha123','outra123'));
});
test('códigos aceitam colagem e rejeitam links e caracteres fora do código',()=>{
  assert.equal(accountCode('123 456'),'123456');assert.equal(accountCode('12345678'),'12345678');for(const value of ['123','abcdef','https://exemplo.com/123456','123456x'])assert.throws(()=>accountCode(value));
});
test('falhas de autenticação e rede são apresentadas em português',()=>{
  assert.equal(accountError({code:'invalid_credentials'}),'E-mail ou senha incorretos.');assert.match(accountError({code:'otp_expired'}),/expirou/);assert.match(accountError({code:'email_address_not_authorized'}),/configurado/);assert.match(accountError(new Error('Failed to fetch')),/internet/);
});
