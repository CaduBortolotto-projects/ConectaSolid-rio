import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import { JSDOM } from 'jsdom';
const code=ts.transpileModule(fs.readFileSync(new URL('../src/copyText.ts',import.meta.url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
function fixture(platform='android',options={}){
  const writes=[];const dom=new JSDOM('<button id="focus">Copiar</button>');dom.window.document.getElementById('focus').focus();
  const navigator={clipboard:{writeText:async value=>{if(options.deny)throw Error('blocked');writes.push(value);}}};
  dom.window.document.execCommand=()=>{if(options.fallback){writes.push(dom.window.document.querySelector('textarea').value);return true;}return false;};
  const module={exports:{}};vm.runInNewContext(code,{module,exports:module.exports,require:name=>name==='react-native'?{Platform:{OS:platform}}:{setStringAsync:async value=>{writes.push(value);return options.nativeResult??true;}},navigator,document:dom.window.document});
  return {copy:module.exports.copyText,writes,dom};
}
test('cópia nativa recebe exatamente o número ou e-mail solicitado',async()=>{const f=fixture();try{assert.equal(await f.copy('+5554999999999'),true);assert.equal(await f.copy('Doador@example.test'),true);assert.deepEqual(f.writes,['+5554999999999','Doador@example.test']);}finally{f.dom.window.close();}});
test('cópia nativa não converte resultado falso em sucesso',async()=>{const f=fixture('android',{nativeResult:false});try{assert.equal(await f.copy('texto'),false);}finally{f.dom.window.close();}});
test('cópia na web usa fallback e limpa o campo temporário',async()=>{const f=fixture('web',{deny:true,fallback:true});try{assert.equal(await f.copy('doador@example.test'),true);assert.deepEqual(f.writes,['doador@example.test']);assert.equal(f.dom.window.document.querySelector('textarea'),null);assert.equal(f.dom.window.document.activeElement.id,'focus');}finally{f.dom.window.close();}});
test('cópia na web informa falha quando ambas as tentativas falham',async()=>{const f=fixture('web',{deny:true,fallback:false});try{assert.equal(await f.copy('texto'),false);assert.equal(f.dom.window.document.querySelector('textarea'),null);}finally{f.dom.window.close();}});
