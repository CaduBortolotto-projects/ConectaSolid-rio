import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizePhone,normalizeSearch,normalizeContactEmail,normalizeInstagram,formatContactPhone,validateItem} from '../src/domain.ts';

test('WhatsApp aceita formato nacional e internacional sem duplicar o país',()=>{
  assert.equal(normalizePhone('(54) 99999-9999'),'5554999999999');
  assert.equal(normalizePhone('+55 (54) 99999-9999'),'5554999999999');
  assert.equal(normalizePhone('(55) 99999-9999'),'5555999999999');
  assert.equal(normalizePhone('54 3222-2222'),'555432222222');
});
test('WhatsApp rejeita DDD inexistente e comprimentos incompletos',()=>{
  for(const value of ['999999999','(20) 99999-9999','+1 555 123 4567','(54) 89999-9999','55549999999999'])assert.throws(()=>normalizePhone(value));
});
test('busca encontra acentos e ignora espaços nas extremidades',()=>{
  assert.equal(normalizeSearch(' MÓVEIS '),'moveis');
  assert.ok(normalizeSearch('Doação de móveis em Caxias').includes(normalizeSearch('moveis')));
});
test('publicação impede descrição curta e mais de seis fotos',()=>{
  const item={title:'Mesa de escritório',category:'Móveis',description:'Mesa usada em boas condições.',city:'Caxias do Sul',state:'RS',phone:'54999999999',photos:[]};
  assert.doesNotThrow(()=>validateItem(item));
  assert.throws(()=>validateItem({...item,description:'curta'}));
  assert.throws(()=>validateItem({...item,state:'ZZ'}));
  assert.throws(()=>validateItem({...item,photos:Array.from({length:7},(_,id)=>({id:String(id),uri:'test'}))}));
});
test('contatos opcionais vazios são normalizados e não substituem WhatsApp obrigatório',()=>{
  assert.equal(normalizeContactEmail('  '),null);assert.equal(normalizeInstagram(''),null);
  const item={title:'Mesa',category:'Móveis',description:'Mesa usada em boas condições.',city:'Caxias',state:'RS',phone:'',contactEmail:'doador@example.test'};
  assert.throws(()=>validateItem(item),/WhatsApp/);
});
test('e-mail para copiar preserva conteúdo e rejeita entradas inválidas',()=>{
  assert.equal(normalizeContactEmail(' Doador@example.test '),'Doador@example.test');
  for(const value of ['abc','a@','a b@example.test','a\nb@example.test','a..b@example.test','mailto:a@example.test'])assert.throws(()=>normalizeContactEmail(value));
});
test('Instagram aceita @usuario e links e remove parâmetros extras',()=>{
  assert.equal(normalizeInstagram('@Meu.Perfil'),'https://www.instagram.com/meu.perfil/');
  assert.equal(normalizeInstagram('instagram.com/meu_perfil/?igsh=123'),'https://www.instagram.com/meu_perfil/');
});
test('Instagram rejeita outros domínios, protocolos e links de publicações',()=>{
  for(const value of ['javascript:alert(1)','https://instagram.com.evil.test/pessoa','https://instagram.com@evil.test/pessoa','https://instagram.com/p/123','https://instagram.com/stories/pessoa/123','https://instagram.com/','https://instagram.com:444/pessoa'])assert.throws(()=>normalizeInstagram(value));
});
test('telefone de contato é formatado para leitura sem mudar o número',()=>{
  assert.equal(formatContactPhone('5554999999999'),'+55 (54) 99999-9999');
});
