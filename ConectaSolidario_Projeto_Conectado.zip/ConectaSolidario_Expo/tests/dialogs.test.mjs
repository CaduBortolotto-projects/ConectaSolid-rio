import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const source=fs.readFileSync(new URL('../src/dialogs.ts',import.meta.url),'utf8');
const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
function fixture(platform='web',confirmed=true){
  const messages=[],native=[];const module={exports:{}};
  vm.runInNewContext(compiled,{module,exports:module.exports,require:()=>({Platform:{OS:platform},Alert:{alert:(...args)=>native.push(args)}}),window:{alert:text=>messages.push(text),confirm:text=>{messages.push(text);return confirmed;}}});
  return {dialog:module.exports.Dialog,messages,native};
}
test('avisos são apresentados na versão web',()=>{const {dialog,messages}=fixture();dialog.alert('Salvo','Anúncio publicado.');assert.equal(messages[0],'Salvo\n\nAnúncio publicado.');});
test('confirmação web executa a ação autorizada',()=>{let deleted=false;const {dialog}=fixture();dialog.alert('Excluir?','Confirmar',[{text:'Cancelar',style:'cancel'},{text:'Excluir',onPress:()=>{deleted=true;}}]);assert.equal(deleted,true);});
test('cancelar na web preserva o anúncio',()=>{let deleted=false,cancelled=false;const {dialog}=fixture('web',false);dialog.alert('Excluir?','Confirmar',[{text:'Cancelar',style:'cancel',onPress:()=>{cancelled=true;}},{text:'Excluir',onPress:()=>{deleted=true;}}]);assert.equal(deleted,false);assert.equal(cancelled,true);});
test('Android usa o diálogo nativo',()=>{const {dialog,native,messages}=fixture('android');dialog.alert('Aviso','Mensagem');assert.equal(native.length,1);assert.equal(native[0][0],'Aviso');assert.equal(messages.length,0);});
