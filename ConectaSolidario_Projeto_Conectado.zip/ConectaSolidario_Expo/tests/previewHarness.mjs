import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM, VirtualConsole } from 'jsdom';
import { IDBFactory } from 'fake-indexeddb';

const html=fs.readFileSync(new URL('../legacy-demo/Preview_Interativa.html',import.meta.url),'utf8');
export const tick=()=>new Promise(resolve=>setTimeout(resolve,40));
export async function withPreview(run,options={}){
  const errors=[];const console=new VirtualConsole();console.on('jsdomError',error=>errors.push(error.message));
  // Atributos inline não são executados e as funções ficam dentro de um escopo
  // isolado, como pode ocorrer em uma prévia incorporada.
  const dom=new JSDOM(html,{url:'https://preview.example.test/',runScripts:'outside-only',virtualConsole:console});
  const w=dom.window;w.indexedDB=options.factory||new IDBFactory();w.structuredClone=structuredClone;
  const copied=[],opened=[];w.confirm=()=>true;w.alert=()=>{};w.open=url=>{opened.push(url);return {};};
  if(options.clipboard!=='missing')Object.defineProperty(w.navigator,'clipboard',{value:{writeText:async text=>{if(options.clipboard==='reject')throw new Error('blocked');copied.push(text);}}});
  w.document.execCommand=()=>{const field=w.document.querySelector('[data-copy-buffer]');if(options.fallback===true&&field)copied.push(field.value);return options.fallback===true;};
  w.HTMLElement.prototype.scrollIntoView=function(){};
  w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','');};
  w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');};
  const code=w.document.querySelector('script').textContent.replace('render();initStorage();','render();window.__previewReady=initStorage();');
  w.eval('(function(){\n'+code+'\n})();');
  await w.__previewReady;
  delete w.__previewReady;
  try{assert.equal(typeof w.enterDemo,'undefined');assert.equal(typeof w.go,'undefined');await run(w,{copied,opened});assert.deepEqual(errors,[]);}
  finally{w.close();}
}
export function click(w,selector){const element=w.document.querySelector(selector);assert.ok(element,'Controle existe: '+selector);element.click();}
export function fill(w,id,value){const input=w.document.getElementById(id);assert.ok(input);input.value=value;input.dispatchEvent(new w.Event('input',{bubbles:true}));}
export function home(w){assert.ok(w.document.getElementById('search'),'O feed foi aberto');}
export function login(w){click(w,'#demoLoginForm button[type=submit]');home(w);}

