import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import React from 'react';
import {create,act} from 'react-test-renderer';
import * as rules from '../src/authRules.ts';
import {normalizePhone} from '../src/domain.ts';
global.IS_REACT_ACT_ENVIRONMENT=true;
const source=ts.transpileModule(fs.readFileSync(new URL('../src/AuthScreen.tsx',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.React,esModuleInterop:true}}).outputText;
async function fixture(t){
  const calls=[],signed=[],state={credentialsError:null,otpError:null,registered:null,recovered:false};
  const user={id:'10000000-0000-4000-8000-000000000001',email:'carlos@example.test'};
  const auth={
    async signInWithPassword(args){calls.push(['login',args]);return {data:state.credentialsError?{}:{user,session:{user}},error:state.credentialsError};},
    async signUp(args){calls.push(['register',args]);state.registered=args;return {data:{session:null},error:null};},
    async verifyOtp(args){calls.push(['verify',args]);if(state.otpError)return {data:{},error:state.otpError};if(args.type==='recovery')state.recovered=true;return {data:{session:{user}},error:null};},
    async resetPasswordForEmail(email){calls.push(['recover',email]);return {error:null};},
    async resend(args){calls.push(['resend',args]);return {error:null};},
    async updateUser(args){assert.equal(state.recovered,true,'Password update requires verified recovery');calls.push(['password',args]);return {error:null};},
    async signOut(args){calls.push(['logout',args]);return {error:null};},
  };
  const imports={react:React,'react-native':{ActivityIndicator:'ActivityIndicator',BackHandler:{addEventListener:()=>({remove(){}})},KeyboardAvoidingView:'KeyboardAvoidingView',Platform:{OS:'android'},Pressable:'Pressable',ScrollView:'ScrollView',StyleSheet:{create:x=>x},Text:'Text',TextInput:'TextInput',View:'View'},'react-native-safe-area-context':{SafeAreaView:'SafeAreaView'},'@expo/vector-icons':{Ionicons:'Ionicons'},'./repository':{client:()=>({auth}),profileFor:async()=>({id:user.id,email:user.email,name:state.registered?.options.data.display_name||'Carlos',type:'Pessoa física',phone:state.registered?.options.data.contact_phone||'5554999999999'})},'./domain':{normalizePhone},'./authRules':rules};
  const module={exports:{}};vm.runInNewContext(source,{module,exports:module.exports,require:name=>{assert.ok(name in imports,'Unexpected import '+name);return imports[name];},setInterval,clearInterval,Date});
  let tree;await act(async()=>{tree=create(React.createElement(module.exports.AuthScreen,{onSignedIn:async p=>signed.push(p)}));});t.after(async()=>{await act(async()=>tree.unmount());});
  const text=node=>node.findAllByType('Text').flatMap(n=>Array.isArray(n.props.children)?n.props.children:[n.props.children]).filter(x=>typeof x==='string');
  const press=async label=>{const button=tree.root.findAllByType('Pressable').find(n=>text(n).includes(label));assert.ok(button,'Button '+label);assert.ok(!button.props.disabled,'Enabled '+label);await act(async()=>{await button.props.onPress();});};
  const fill=async(label,value)=>{await act(async()=>tree.root.findByProps({accessibilityLabel:label}).props.onChangeText(value));};
  const includes=value=>text(tree.root).some(s=>s.includes(value));
  return {tree,calls,signed,state,press,fill,includes};
}
test('acesso real começa vazio, rejeita credenciais inválidas e autentica via servidor',async t=>{
  const f=await fixture(t);assert.equal(f.tree.root.findByProps({accessibilityLabel:'E-mail'}).props.value,'');
  await f.fill('E-mail','carlos@example.test');await f.fill('Senha','senha123');f.state.credentialsError={code:'invalid_credentials'};await f.press('Entrar');assert.ok(f.includes('E-mail ou senha incorretos'));assert.equal(f.signed.length,0);
  f.state.credentialsError=null;await f.press('Entrar');assert.equal(f.signed.length,1);assert.equal(f.calls.filter(c=>c[0]==='login').length,2);
});
test('cadastro exige WhatsApp e senhas iguais, envia código e só entra após verificação',async t=>{
  const f=await fixture(t);await f.press('Ainda não tenho conta · Cadastrar');await f.fill('Nome ou nome da ONG',' Carlos ');await f.fill('E-mail',' CARLOS@example.test ');await f.fill('Senha','senha123');await f.fill('Confirmar senha','outra123');
  await f.press('Criar conta');assert.equal(f.calls.length,0);assert.ok(f.includes('WhatsApp brasileiro'));
  await f.fill('WhatsApp com DDD','54 99999-9999');await f.press('Criar conta');assert.equal(f.calls.length,0);assert.ok(f.includes('senhas não coincidem'));
  await f.fill('Confirmar senha','senha123');await f.press('Criar conta');assert.equal(f.calls[0][1].email,'carlos@example.test');assert.equal(f.calls[0][1].options.data.contact_phone,'5554999999999');assert.equal(f.signed.length,0);assert.ok(f.includes('Confirme seu e-mail'));
  await f.fill('Código recebido por e-mail','123456');f.state.otpError={code:'otp_expired'};await f.press('Confirmar código');assert.equal(f.signed.length,0);assert.ok(f.includes('expirou'));
  f.state.otpError=null;await f.press('Confirmar código');assert.equal(f.signed.length,1);assert.equal(f.calls.at(-1)[1].type,'email');
});
test('recuperação verifica o código antes de trocar a senha e encerra a sessão temporária',async t=>{
  const f=await fixture(t);await f.press('Esqueci minha senha');await f.fill('E-mail','carlos@example.test');await f.press('Enviar código');assert.equal(f.calls[0][0],'recover');assert.ok(f.includes('Código de recuperação'));
  await f.fill('Código recebido por e-mail','123');await f.press('Confirmar código');assert.equal(f.calls.length,1);
  await f.fill('Código recebido por e-mail','123456');await f.press('Confirmar código');assert.equal(f.calls.at(-1)[1].type,'recovery');assert.equal(f.signed.length,0);
  await f.fill('Nova senha','novasenha123');await f.fill('Confirmar nova senha','diferente123');await f.press('Salvar nova senha');assert.equal(f.calls.filter(c=>c[0]==='password').length,0);
  await f.fill('Confirmar nova senha','novasenha123');await f.press('Salvar nova senha');assert.equal(f.calls.at(-2)[0],'password');assert.equal(f.calls.at(-1)[0],'logout');assert.equal(f.calls.at(-1)[1].scope,'local');assert.equal(f.tree.root.findByProps({accessibilityLabel:'Senha'}).props.value,'');assert.ok(f.includes('Senha atualizada'));
});
test('cancelar uma recuperação validada também encerra a sessão temporária',async t=>{
  const f=await fixture(t);await f.press('Esqueci minha senha');await f.fill('E-mail','carlos@example.test');await f.press('Enviar código');await f.fill('Código recebido por e-mail','123456');await f.press('Confirmar código');await f.press('Voltar para entrar');assert.equal(f.calls.at(-1)[0],'logout');assert.equal(f.signed.length,0);
});
