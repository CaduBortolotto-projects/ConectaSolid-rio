export function accountEmail(value:string):string {
  const email=value.trim().toLowerCase();
  if(email.length>254||!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email))throw new Error('Informe um e-mail válido.');
  return email;
}
export function accountName(value:string):string {
  const name=value.trim();
  if(name.length<2||name.length>80)throw new Error('O nome deve ter entre 2 e 80 caracteres.');
  return name;
}
export function accountPassword(password:string,confirmation?:string):string {
  if(password.length<8)throw new Error('Crie uma senha com pelo menos 8 caracteres.');
  if(password.length>72)throw new Error('Use uma senha com até 72 caracteres.');
  if(confirmation!==undefined&&password!==confirmation)throw new Error('As senhas não coincidem.');
  return password;
}
export function accountCode(value:string):string {
  const code=value.replace(/\s/g,'');
  if(!/^\d{6,10}$/.test(code))throw new Error('Digite o código numérico recebido por e-mail.');
  return code;
}
export function accountError(error:unknown):string {
  const code=typeof error==='object'&&error!==null&&'code' in error?String(error.code):'';
  const messages:Record<string,string>={
    invalid_credentials:'E-mail ou senha incorretos.',email_not_confirmed:'Confirme seu e-mail para entrar.',
    user_already_exists:'Este e-mail já tem uma conta. Entre ou recupere sua senha.',email_exists:'Este e-mail já tem uma conta.',
    otp_expired:'O código expirou ou está incorreto. Solicite um novo código.',
    over_email_send_rate_limit:'Aguarde alguns minutos antes de solicitar outro e-mail.',
    over_request_rate_limit:'Muitas tentativas. Aguarde alguns minutos e tente novamente.',
    weak_password:'Escolha uma senha mais forte, com letras, números e símbolos.',
    same_password:'Escolha uma senha diferente da anterior.',
    email_address_not_authorized:'O envio de e-mails ainda precisa ser configurado pelo responsável do aplicativo.',
    signup_disabled:'O cadastro está temporariamente indisponível.',
  };
  if(messages[code])return messages[code];
  const message=error instanceof Error?error.message:'Não foi possível concluir. Tente novamente.';
  if(/fetch|network|timeout/i.test(message))return 'Não foi possível conectar. Confira sua internet e tente novamente.';
  return message;
}
