export function normalizeContactEmail(value) {
  const email=String(value??'').trim();
  if(!email)return null;
  if(email.length>254||!(/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i).test(email)||email.split('@')[0].startsWith('.')||email.split('@')[0].endsWith('.')||email.split('@')[0].includes('..'))
    throw new Error('Confira o e-mail para contato ou deixe esse campo vazio.');
  return email;
}
export function normalizeInstagram(value) {
  let text=String(value??'').trim();
  if(!text)return null;
  let username;
  if(/^@?[a-z0-9._]+$/i.test(text)){username=text.replace(/^@/,'');}
  else{
    if(/^(?:www\.)?instagram\.com\//i.test(text))text='https://'+text;
    let url;try{url=new URL(text);}catch{throw new Error('Informe seu @usuario ou um link de perfil do Instagram.');}
    if(!['https:','http:'].includes(url.protocol)||!['instagram.com','www.instagram.com'].includes(url.hostname.toLowerCase())||url.username||url.password||url.port)
      throw new Error('Use um link de perfil do Instagram, como https://www.instagram.com/seu.usuario/.');
    const parts=url.pathname.split('/').filter(Boolean);
    if(parts.length!==1)throw new Error('Informe o perfil do Instagram, em vez de uma publicação ou story.');
    username=parts[0];
  }
  username=username.toLowerCase();
  if(!/^[a-z0-9._]{1,30}$/.test(username)||username.startsWith('.')||username.endsWith('.')||username.includes('..')||['p','reel','reels','stories','explore','accounts','direct','about','legal','privacy','share','oauth'].includes(username))
    throw new Error('Confira o nome do perfil do Instagram. Use apenas letras, números, ponto ou sublinhado.');
  return 'https://www.instagram.com/'+username+'/';
}
export function formatContactPhone(phone) {
  const digits=String(phone).replace(/\D/g,'');
  const number=digits.slice(4);
  return '+55 ('+digits.slice(2,4)+') '+number.slice(0,-4)+'-'+number.slice(-4);
}
