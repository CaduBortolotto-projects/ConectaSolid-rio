import React,{useEffect,useRef,useState} from 'react';
import { ActivityIndicator, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { ContactInfo, Item, formatContactPhone, normalizeContactEmail, normalizeInstagram, normalizePhone } from './domain';
import { getContacts } from './repository';
import { isOnline } from './supabase';
import { copyText } from './copyText';

export function ContactsCard({item,isOwner}:{item:Item;isOwner:boolean}){
  const [info,setInfo]=useState<ContactInfo|null>(null),[loading,setLoading]=useState(false),[failed,setFailed]=useState(false),[retry,setRetry]=useState(0),[copied,setCopied]=useState(''),[message,setMessage]=useState('');
  const timer=useRef<ReturnType<typeof setTimeout>|null>(null),alive=useRef(true);
  useEffect(()=>{alive.current=true;return ()=>{alive.current=false;if(timer.current)clearTimeout(timer.current);};},[]);
  useEffect(()=>{
    let active=true;setInfo(null);setFailed(false);setMessage('');setCopied('');
    if(item.status==='doado'&&!isOwner){setLoading(false);return;}
    setLoading(true);
    (async()=>{
      try{
        const result=isOnline?await getContacts(item.id):item.phone?{phone:normalizePhone(item.phone),email:normalizeContactEmail(item.contactEmail),instagramUrl:normalizeInstagram(item.instagramUrl)}:null;
        if(active)setInfo(result);
      }catch{if(active)setFailed(true);}finally{if(active)setLoading(false);}
    })();
    return ()=>{active=false;};
  },[item,isOwner,retry]);
  const copy=async(value:string,label:string)=>{
    let ok=false;try{ok=await copyText(value);}catch{}
    if(!alive.current)return;
    if(!ok){setCopied('');setMessage('Não foi possível copiar automaticamente. Pressione e selecione o contato para copiar manualmente.');return;}
    setMessage(label+' copiado.');setCopied(label);if(timer.current)clearTimeout(timer.current);
    timer.current=setTimeout(()=>{if(alive.current)setCopied('');},2200);
  };
  const row=(label:string,display:string,value:string)=><View style={s.row}><View style={s.value}><Text style={s.label}>{label}</Text><Text selectable style={s.text}>{display}</Text></View><Pressable accessibilityRole="button" accessibilityLabel={'Copiar '+label} onPress={()=>void copy(value,label)} style={s.button}><Text style={s.buttonText}>{copied===label?'Copiado ✓':'Copiar'}</Text></Pressable></View>;
  return <View style={s.card}><Text style={s.heading}>Contatos do doador</Text>
    {loading?<View style={s.loading}><ActivityIndicator color="#2376C9"/><Text style={s.note}>Carregando contatos…</Text></View>:failed?<><Text style={s.note}>Não foi possível carregar os contatos.</Text><Pressable accessibilityRole="button" onPress={()=>setRetry(x=>x+1)} style={s.button}><Text style={s.buttonText}>Tentar novamente</Text></Pressable></>:!info?<Text style={s.note}>{item.status==='doado'&&!isOwner?'Esta doação já foi concluída.':'Este anúncio é de exemplo e não tem contatos cadastrados.'}</Text>:<>
      {row('WhatsApp',formatContactPhone(info.phone),'+'+info.phone)}
      {info.email&&row('E-mail',info.email,info.email)}
      {info.instagramUrl&&<View style={s.instagram}><Text style={s.label}>Instagram</Text><Text selectable style={s.text}>{'@'+info.instagramUrl.split('/').filter(Boolean).at(-1)}</Text><Pressable accessibilityRole="link" onPress={()=>void Linking.openURL(info.instagramUrl!).catch(()=>{if(alive.current)setMessage('Não foi possível abrir o Instagram. Tente novamente.');})} style={[s.button,{marginTop:10}]}><Text style={s.buttonText}>Abrir Instagram ↗</Text></Pressable></View>}
      <Text style={s.note}>Você pode copiar o WhatsApp e o e-mail ou abrir o perfil do Instagram.</Text>
    </>}
    {!!message&&<Text accessibilityLiveRegion="polite" style={s.feedback}>{message}</Text>}
  </View>;
}
const s=StyleSheet.create({
  card:{backgroundColor:'white',borderRadius:18,borderWidth:1,borderColor:'#DCE8F2',padding:16,marginTop:20,marginBottom:12},
  heading:{fontSize:18,fontWeight:'800',color:'#173456',marginBottom:5},
  row:{flexDirection:'row',alignItems:'center',gap:10,paddingVertical:14,borderBottomWidth:1,borderBottomColor:'#E5EDF4'},
  value:{flex:1,minWidth:0},label:{fontSize:12,color:'#637B93',fontWeight:'700',marginBottom:5},text:{color:'#193858',fontSize:15,lineHeight:22,flexShrink:1},
  button:{minHeight:44,backgroundColor:'#E9F4FF',borderRadius:10,paddingHorizontal:13,paddingVertical:11,alignItems:'center',justifyContent:'center',flexShrink:0},
  buttonText:{color:'#2376C9',fontSize:13,fontWeight:'800'},note:{fontSize:12,color:'#6A8097',lineHeight:19,marginTop:12},feedback:{fontSize:12,color:'#205C83',lineHeight:19,marginTop:12},instagram:{paddingVertical:14},loading:{flexDirection:'row',alignItems:'center',gap:10,paddingVertical:10},
});
