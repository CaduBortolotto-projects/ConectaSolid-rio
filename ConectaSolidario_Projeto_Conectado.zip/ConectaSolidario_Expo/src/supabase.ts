import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, processLock } from '@supabase/supabase-js';
import { AppState, Platform } from 'react-native';

export const isOnline = process.env.EXPO_PUBLIC_BACKEND !== 'demo';
const url = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY || '';
export const configurationError = isOnline && (!/^https:\/\/[^/]+/.test(url)||!key.startsWith('sb_publishable_'))
  ? 'A conexão do aplicativo ainda não foi configurada. Entre em contato com o responsável pelo ConectaSolidário.' : '';
export const supabase = isOnline && !configurationError ? createClient(url,key,{
  auth:{storage:AsyncStorage,autoRefreshToken:true,persistSession:true,detectSessionInUrl:false,lock:processLock},
}) : null;
if(Platform.OS!=='web'&&supabase){
  const client=supabase;
  AppState.addEventListener('change',state=>state==='active'?client.auth.startAutoRefresh():client.auth.stopAutoRefresh());
}
