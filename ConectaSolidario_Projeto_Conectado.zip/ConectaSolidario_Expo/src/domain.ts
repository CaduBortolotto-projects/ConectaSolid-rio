import { normalizeContactEmail, normalizeInstagram } from './contactRules.js';
export { normalizeContactEmail, normalizeInstagram, formatContactPhone } from './contactRules.js';
export type ContactInfo={phone:string;email:string|null;instagramUrl:string|null};
export type Category = 'Todos' | 'Roupas' | 'Móveis' | 'Eletrônicos' | 'Livros' | 'Outros';
export type Photo = { id: string; uri: string; path?: string; fingerprint?: string };
export type Item = {
  id: string; title: string; category: Exclude<Category, 'Todos'>; description: string;
  city: string; state: string; image: string; photos?: Photo[]; phone?: string; contactEmail?: string|null; instagramUrl?: string|null; owner: string;
  ownerId: string; lat?: number; lon?: number; status: 'disponivel' | 'doado'; date: string;
};
export type Profile = { id: string; name: string; email: string; type: 'Pessoa física' | 'ONG';phone?:string;contactEmail?:string|null;instagramUrl?:string|null };
export const DEMO_EMAIL='demo@conectasolidario.test';
export const DEMO_NAME='Visitante Demo';
export const MAX_PHOTOS = 6;
export const STATES = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');
const ddds = '11 12 13 14 15 16 17 18 19 21 22 24 27 28 31 32 33 34 35 37 38 41 42 43 44 45 46 47 48 49 51 53 54 55 61 62 63 64 65 66 67 68 69 71 73 74 75 77 79 81 82 83 84 85 86 87 88 89 91 92 93 94 95 96 97 98 99'.split(' ');
export function normalizePhone(value: string): string {
  let digits=value.replace(/\D/g,'');
  // DDD 55 também é um DDD brasileiro: primeiro considere o tamanho nacional.
  if(digits.length===10||digits.length===11)digits='55'+digits;
  if(!/^55[1-9]{2}(?:[2-5]\d{7}|9\d{8})$/.test(digits)||!ddds.includes(digits.slice(2,4)))
    throw new Error('Informe um WhatsApp brasileiro válido com DDD. Ex.: (54) 99999-9999.');
  return digits;
}
export const normalizeSearch=(value:string)=>value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR').trim();
export function validateItem(item:Item): void {
  if(!['Roupas','Móveis','Eletrônicos','Livros','Outros'].includes(item.category))throw new Error('Selecione uma categoria válida.');
  if(item.title.trim().length<3||item.title.trim().length>100)throw new Error('O nome do produto deve ter entre 3 e 100 caracteres.');
  if(item.description.trim().length<10||item.description.trim().length>2000)throw new Error('A descrição deve ter entre 10 e 2.000 caracteres.');
  if(item.city.trim().length<2||item.city.trim().length>80)throw new Error('Informe uma cidade válida.');
  if(!STATES.includes(item.state))throw new Error('Selecione uma UF válida.');
  if((item.photos?.length||0)>MAX_PHOTOS)throw new Error('O limite é de 6 fotos por anúncio.');
  normalizePhone(item.phone||'');
  normalizeContactEmail(item.contactEmail);
  normalizeInstagram(item.instagramUrl);
}
export function itemPhotos(item:Item): Photo[] {return item.photos?.length?item.photos:item.image?[{id:'legacy',uri:item.image}]:[];}
