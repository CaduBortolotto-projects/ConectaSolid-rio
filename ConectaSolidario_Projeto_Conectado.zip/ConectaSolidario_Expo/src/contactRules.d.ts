export function normalizeContactEmail(value?:string|null):string|null;
export function normalizeInstagram(value?:string|null):string|null;
export function formatContactPhone(phone:string):string;
