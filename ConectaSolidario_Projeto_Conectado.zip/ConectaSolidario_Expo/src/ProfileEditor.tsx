import React,{useRef,useState} from 'react';
import {ActivityIndicator,KeyboardAvoidingView,Platform,ScrollView,Text,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {AuthButton,AuthField} from './AuthScreen';
import {Profile} from './domain';
import {saveProfile} from './repository';
import {accountError} from './authRules';

export function ProfileEditor({profile,onSaved,onBack,onLogout,onBusyChange}:{profile:Profile;onSaved:(profile:Profile)=>void;onBack:()=>void;onLogout:()=>void;onBusyChange:(value:boolean)=>void}){
  const [name,setName]=useState(profile.name),[phone,setPhone]=useState(profile.phone||'');
  const [email,setEmail]=useState(profile.contactEmail||''),[instagram,setInstagram]=useState(profile.instagramUrl||'');
  const [busy,setBusy]=useState(false),[error,setError]=useState('');const pending=useRef(false);
  const save=async()=>{if(pending.current)return;pending.current=true;setBusy(true);onBusyChange(true);setError('');try{onSaved(await saveProfile({...profile,name,phone,contactEmail:email,instagramUrl:instagram}));}catch(e){setError(accountError(e));}finally{pending.current=false;setBusy(false);onBusyChange(false);}};
  return <SafeAreaView style={{flex:1,backgroundColor:'#F5F9FD'}}><KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':undefined} style={{flex:1}}><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{padding:24,paddingBottom:40}}>
    <Text style={{fontSize:25,color:'#173456',fontWeight:'900',marginBottom:12}}>{profile.phone?'Meu cadastro':'Complete seu cadastro'}</Text>
    <Text style={{color:'#708299',fontSize:14,lineHeight:22,marginBottom:24}}>Seu acesso é {profile.email}. O WhatsApp é obrigatório; e-mail de contato e Instagram são opcionais. Você escolhe os contatos de cada doação antes de publicar.</Text>
    <AuthField label="Nome ou nome da ONG" value={name} onChange={setName}/>
    <AuthField label="WhatsApp com DDD" value={phone} onChange={setPhone} kind="phone"/>
    <AuthField label="E-mail para contato (opcional)" value={email} onChange={setEmail} kind="email"/>
    <AuthField label="Instagram (opcional)" value={instagram} onChange={setInstagram} maxLength={500}/>
    {!!error&&<Text accessibilityRole="alert" style={{color:'#A23636',lineHeight:21,marginBottom:16}}>{error}</Text>}
    <AuthButton label="Salvar meu cadastro" onPress={()=>void save()} disabled={busy}/>
    {busy&&<ActivityIndicator color="#2376C9" style={{margin:12}}/>}
    {profile.phone?<AuthButton label="Voltar ao perfil" onPress={onBack} disabled={busy} secondary/>:<AuthButton label="Sair da conta" onPress={onLogout} disabled={busy} secondary/>}
    <View style={{height:16}}/><Text style={{color:'#708299',fontSize:12,lineHeight:19}}>Alterar seu cadastro atualiza as sugestões de contato para novas doações. Para mudar os contatos de uma doação já publicada, edite o anúncio.</Text>
  </ScrollView></KeyboardAvoidingView></SafeAreaView>;
}
