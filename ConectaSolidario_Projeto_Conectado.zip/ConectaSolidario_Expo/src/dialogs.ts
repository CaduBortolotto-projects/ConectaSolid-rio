import { Alert, AlertButton, Platform } from 'react-native';

// Alert do React Native Web é vazio nesta versão. Use os diálogos do navegador.
export const Dialog={
  alert(title:string,message?:string,buttons?:AlertButton[]):void {
    if(Platform.OS!=='web'){Alert.alert(title,message,buttons);return;}
    const text=message?`${title}\n\n${message}`:title;
    if(!buttons?.length){window.alert(text);return;}
    const accept=buttons.find(button=>button.style!=='cancel');
    const cancel=buttons.find(button=>button.style==='cancel');
    if(window.confirm(text))accept?.onPress?.();else cancel?.onPress?.();
  },
};
