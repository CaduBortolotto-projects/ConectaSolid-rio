import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';
import * as Crypto from 'expo-crypto';
import { decode } from 'base64-arraybuffer';
import { configurationError, supabase } from './supabase';
import { accountName } from './authRules';
import { ContactInfo, Item, Photo, Profile, itemPhotos, normalizePhone, normalizeContactEmail, normalizeInstagram, validateItem } from './domain';

const BUCKET='donation-photos';
const LOCAL_KEY='conectasolidario:donations:v2';
export function client(){if(!supabase)throw new Error(configurationError||'O modo online não está configurado.');return supabase;}
function check(error:{message:string}|null){if(error)throw new Error(error.message);}
export async function profileFor(id:string,email:string):Promise<Profile>{
  const {data,error}=await client().from('profiles').select('id,display_name,account_type').eq('id',id).single();check(error);if(!data)throw new Error('Seu perfil não foi encontrado. Confira a configuração da base.');
  const contacts=await client().from('profile_contacts').select('phone,email,instagram_url').eq('user_id',id).maybeSingle();check(contacts.error);
  return {id,name:data.display_name,email,type:data.account_type,phone:contacts.data?.phone||'',contactEmail:contacts.data?.email||null,instagramUrl:contacts.data?.instagram_url||null};
}
export async function saveProfile(profile:Profile):Promise<Profile>{
  const name=accountName(profile.name),phone=normalizePhone(profile.phone||''),contactEmail=normalizeContactEmail(profile.contactEmail),instagramUrl=normalizeInstagram(profile.instagramUrl);
  const {error}=await client().rpc('save_profile',{p_name:name,p_account_type:profile.type,p_phone:phone,p_email:contactEmail,p_instagram_url:instagramUrl});check(error);
  return {...profile,name,phone,contactEmail,instagramUrl};
}
type DonationRow={id:string;owner_id:string;title:string;category:Item['category'];description:string;city:string;state:string;photo_paths:string[];status:Item['status'];approx_lat:number|null;approx_lon:number|null;created_at:string;profiles:{display_name:string}|{display_name:string}[]|null};
function mapRow(row:DonationRow):Item{
  const joined=Array.isArray(row.profiles)?row.profiles[0]:row.profiles;
  const photos=(row.photo_paths||[]).map(path=>({id:path,uri:client().storage.from(BUCKET).getPublicUrl(path).data.publicUrl,path}));
  return {id:row.id,title:row.title,category:row.category,description:row.description,city:row.city,state:row.state,photos,image:photos[0]?.uri||'',ownerId:row.owner_id,owner:joined?.display_name||'Doador',status:row.status,lat:row.approx_lat??undefined,lon:row.approx_lon??undefined,date:new Date(row.created_at).toLocaleDateString('pt-BR')};
}
export async function listOnline(ownerId:string):Promise<Item[]>{
  // Uma consulta autenticada inclui as disponíveis e as doações do próprio usuário.
  const {data,error}=await client().from('donations').select('*,profiles!donations_owner_id_fkey(display_name)').or(`status.eq.disponivel,owner_id.eq.${ownerId}`).order('created_at',{ascending:false}).limit(500);check(error);
  return (data as unknown as DonationRow[]).map(mapRow);
}
export async function getContacts(id:string):Promise<ContactInfo>{
  const {data,error}=await client().from('donation_contacts').select('phone,email,instagram_url').eq('donation_id',id).single();check(error);if(!data)throw new Error('Os contatos não estão disponíveis. Atualize a lista de doações.');
  return {phone:normalizePhone(data.phone),email:normalizeContactEmail(data.email),instagramUrl:normalizeInstagram(data.instagram_url)};
}
async function bytesFor(photo:Photo):Promise<ArrayBuffer>{
  if(Platform.OS==='web'){const r=await fetch(photo.uri);if(!r.ok)throw new Error('Não foi possível ler a foto selecionada.');return r.arrayBuffer();}
  const base64=await FileSystem.readAsStringAsync(photo.uri,{encoding:FileSystem.EncodingType.Base64});return decode(base64);
}
export type SaveResult={item:Item;warning?:string};
export async function saveOnline(item:Item,previous?:Item):Promise<SaveResult>{
  validateItem(item);const api=client();const uploaded:string[]=[];const photos:Photo[]=[];
  const before=await api.from('donations').select('photo_paths').eq('id',item.id).eq('owner_id',item.ownerId).maybeSingle();check(before.error);
  const previousPaths:string[]=before.data?.photo_paths||itemPhotos(previous||{...item,photos:[],image:''}).filter(p=>p.path).map(p=>p.path!);
  let safeToCleanup=true;
  try{
    for(const photo of itemPhotos(item)){
      if(photo.path){photos.push(photo);continue;}
      const path=`${item.ownerId}/${item.id}/${Crypto.randomUUID()}.jpg`;
      const bytes=await bytesFor(photo);
      if(bytes.byteLength>5*1024*1024)throw new Error('Uma foto ultrapassou o limite de 5 MB após processamento.');
      const {error}=await api.storage.from(BUCKET).upload(path,bytes,{contentType:'image/jpeg',upsert:false});check(error);uploaded.push(path);
      photos.push({...photo,path,uri:api.storage.from(BUCKET).getPublicUrl(path).data.publicUrl});
    }
    safeToCleanup=false;
    const {error}=await api.rpc('save_donation',{p_id:item.id,p_title:item.title.trim(),p_category:item.category,p_description:item.description.trim(),p_city:item.city.trim(),p_state:item.state,p_phone:normalizePhone(item.phone||''),p_photo_paths:photos.map(p=>p.path!),p_lat:item.lat??null,p_lon:item.lon??null,p_email:normalizeContactEmail(item.contactEmail),p_instagram_url:normalizeInstagram(item.instagramUrl)});
    if(error){safeToCleanup=/^(?:[0-9A-Z]{5}|PGRST\d{3})$/.test(error.code||'');check(error);}
  }catch(error){
    // Uma queda de rede pode ocorrer depois do COMMIT. Nunca apague as fotos
    // de uma gravação cujo resultado não foi confirmado. O ID do rascunho é estável.
    if(!safeToCleanup)throw new Error('A conexão caiu antes de confirmar a gravação. Atualize seus anúncios antes de tentar novamente. Seu rascunho e as fotos enviadas foram preservados.');
    if(uploaded.length){const cleanup=await api.storage.from(BUCKET).remove(uploaded);if(cleanup.error)throw new Error(`${error instanceof Error?error.message:'Falha ao salvar.'} Algumas fotos enviadas precisam de limpeza no Storage.`);}
    throw error;
  }
  const removed=previousPaths.filter(path=>!photos.some(next=>next.path===path));
  const saved={...item,phone:undefined,contactEmail:undefined,instagramUrl:undefined,photos,image:photos[0]?.uri||''};
  if(removed.length){const {error}=await api.storage.from(BUCKET).remove(removed);if(error)return {item:saved,warning:'Anúncio salvo. Algumas fotos antigas precisam de limpeza no Storage.'};}
  return {item:saved};
}
export async function statusOnline(item:Item):Promise<Item>{
  const status=item.status==='doado'?'disponivel':'doado';
  const {data,error}=await client().from('donations').update({status}).eq('id',item.id).eq('owner_id',item.ownerId).select('id').single();check(error);if(!data)throw new Error('Anúncio não encontrado.');return {...item,status};
}
export async function deleteOnline(item:Item):Promise<string|undefined>{
  const api=client();const {data,error}=await api.from('donations').delete().eq('id',item.id).eq('owner_id',item.ownerId).select('id').single();check(error);if(!data)throw new Error('Anúncio não encontrado.');
  const paths=itemPhotos(item).filter(p=>p.path).map(p=>p.path!);
  if(paths.length){const {error}=await api.storage.from(BUCKET).remove(paths);if(error)return 'Anúncio excluído. Algumas fotos precisam de limpeza no Storage.';}
}
export async function readDemo():Promise<Item[]>{const raw=await AsyncStorage.getItem(LOCAL_KEY);if(!raw)return [];const data=JSON.parse(raw);if(!Array.isArray(data))throw new Error('Os dados locais não puderam ser lidos.');return data;}
export async function writeDemo(items:Item[]):Promise<void>{await AsyncStorage.setItem(LOCAL_KEY,JSON.stringify(items.filter(x=>!x.ownerId.startsWith('demo-seed-'))));}
export async function persistDemoPhotos(item:Item):Promise<Item>{
  const photos:Photo[]=[];
  for(const photo of itemPhotos(item)){
    if(Platform.OS==='web'){
      if(photo.uri.startsWith('data:')){photos.push(photo);continue;}
      const blob=await (await fetch(photo.uri)).blob();
      const uri=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Falha ao guardar foto.'));reader.readAsDataURL(blob);});
      photos.push({...photo,uri});
    }else{
      if(!FileSystem.documentDirectory)throw new Error('Armazenamento local indisponível.');
      const folder=FileSystem.documentDirectory+'donation-photos/';await FileSystem.makeDirectoryAsync(folder,{intermediates:true});
      const uri=folder+photo.id+'.jpg';if(photo.uri!==uri)await FileSystem.copyAsync({from:photo.uri,to:uri});photos.push({...photo,uri});
    }
  }
  return {...item,photos,image:photos[0]?.uri||''};
}
export async function cleanupDemoPhotos(oldItem:Item,newItem?:Item):Promise<void>{
  if(Platform.OS==='web'||!FileSystem.documentDirectory)return;
  const keep=new Set(newItem?itemPhotos(newItem).map(p=>p.uri):[]);
  for(const p of itemPhotos(oldItem))if(!keep.has(p.uri)&&p.uri.startsWith(FileSystem.documentDirectory+'donation-photos/'))await FileSystem.deleteAsync(p.uri,{idempotent:true}).catch(()=>undefined);
}
