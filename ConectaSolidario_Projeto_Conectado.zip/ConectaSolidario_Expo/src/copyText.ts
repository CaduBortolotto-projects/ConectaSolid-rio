import { Platform } from 'react-native';
import * as Clipboard from 'expo-clipboard';

export async function copyText(text:string):Promise<boolean>{
  if(Platform.OS!=='web')return Clipboard.setStringAsync(text);
  try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return true;}}catch{}
  const active=document.activeElement as HTMLElement|null;
  const field=document.createElement('textarea');field.value=text;field.readOnly=true;
  field.style.cssText='position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;';
  document.body.appendChild(field);field.select();let copied=false;
  try{copied=document.execCommand?.('copy')===true;}catch{}
  field.remove();active?.focus?.({preventScroll:true});return copied;
}
