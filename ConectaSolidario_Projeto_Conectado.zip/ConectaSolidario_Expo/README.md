# ConectaSolidário — contas reais e preparação do APK

React Native, Expo SDK 57, TypeScript e Supabase. Versão 1.0.0.

## Recursos

- Cadastro de pessoa física ou ONG: nome, e-mail, WhatsApp e confirmação de senha.
- Login com senha, confirmação do e-mail por código e recuperação de senha por código.
- Sessão persistente, validada no servidor ao reabrir; saída neste aparelho.
- Perfil editável: WhatsApp obrigatório, e-mail de contato e Instagram opcionais.
- Contatos privados do perfil separados dos contatos escolhidos para cada anúncio.
- Doações no banco, até seis fotos, capa, ampliação, edição, conclusão e exclusão pelo dono.
- Busca por produto e cidade; distâncias somente após autorização do GPS.
- Perfil EAS `apk` configurado para um instalador Android independente do Expo Go.

## Estado da entrega

O projeto Supabase `ConectaSolidario` foi criado na região São Paulo, no plano Free com cotação de US$ 0/mês. As quatro tabelas, o bucket de fotos e as permissões já estão instalados. Os testes transacionais no servidor e a conexão HTTP com a chave publicável passaram. A configuração pública está em `.env` e `.env.example`.

**Ainda falta configurar o SMTP e os modelos de confirmação/recuperação, vincular a conta Expo e compilar o APK assinado. Este ZIP é o projeto; não contém um APK.**
O modo real é o padrão. A compilação do APK é bloqueada quando falta a configuração do banco ou quando o backend é de demonstração.

Siga `GUIA_CONEXAO.md` e depois `GUIA_APK.md`. O segundo guia inclui um caminho pelo navegador para o computador da empresa.

Para desenvolver com Node.js 22.13 ou superior:

```sh
npm ci
# O .env incluído já aponta para o banco real.
npx expo start
```

Para conferir:

```sh
npm run typecheck
npm test
```

`VALIDACAO.md` registra o alcance dos testes. A prévia antiga está arquivada em `legacy-demo/`; ela não é o aplicativo real e não entra no APK.
