-- ConectaSolidário: executar no SQL Editor de um projeto Supabase novo.
-- Pode ser repetido neste mesmo esquema. Não substitui migrações de esquemas diferentes.
begin;

create schema if not exists private;
revoke all on schema private from public,anon,authenticated;

create or replace function public.valid_photo_paths(paths text[],owner_id uuid,donation_id uuid)
returns boolean language sql immutable set search_path='' as $$
  select cardinality(paths)<=6 and array_position(paths,null) is null
    and cardinality(paths)=(select count(distinct p) from unnest(paths) p)
    and not exists(select 1 from unnest(paths) p where
      p !~ ('^'||owner_id::text||'/'||donation_id::text||'/[0-9a-f-]{36}\.jpg$'));
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check(char_length(trim(display_name)) between 2 and 80),
  account_type text not null default 'Pessoa física' check(account_type in ('Pessoa física','ONG')),
  created_at timestamptz not null default now()
);
create table if not exists public.donations (
  id uuid primary key,
  owner_id uuid not null constraint donations_owner_id_fkey references public.profiles(id) on delete cascade,
  title text not null check(char_length(trim(title)) between 3 and 100),
  category text not null check(category in ('Roupas','Móveis','Eletrônicos','Livros','Outros')),
  description text not null check(char_length(trim(description)) between 10 and 2000),
  city text not null check(char_length(trim(city)) between 2 and 80),
  state text not null default 'RS' check(state in ('AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO')),
  photo_paths text[] not null default '{}',
  status text not null default 'disponivel' check(status in ('disponivel','doado')),
  approx_lat numeric(5,2),
  approx_lon numeric(6,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check((approx_lat is null and approx_lon is null) or
        (approx_lat is not null and approx_lon is not null and approx_lat between -90 and 90 and approx_lon between -180 and 180)),
  check(public.valid_photo_paths(photo_paths,owner_id,id))
);
create table if not exists public.donation_contacts (
  donation_id uuid primary key references public.donations(id) on delete cascade,
  phone text not null check(phone ~ '^55(11|12|13|14|15|16|17|18|19|21|22|24|27|28|31|32|33|34|35|37|38|41|42|43|44|45|46|47|48|49|51|53|54|55|61|62|63|64|65|66|67|68|69|71|73|74|75|77|79|81|82|83|84|85|86|87|88|89|91|92|93|94|95|96|97|98|99)([2-5][0-9]{7}|9[0-9]{8})$')
);
create index if not exists donations_owner_idx on public.donations(owner_id);
create index if not exists donations_feed_idx on public.donations(status,created_at desc);

create or replace function private.handle_new_user()
returns trigger language plpgsql security definer set search_path='' as $$
begin
  if tg_table_schema<>'auth' or tg_table_name<>'users' or tg_op<>'INSERT' then raise exception 'Gatilho de cadastro inválido.'; end if;
  insert into public.profiles(id,display_name,account_type)
  values(new.id,case when char_length(trim(new.raw_user_meta_data->>'display_name'))>=2 then left(trim(new.raw_user_meta_data->>'display_name'),80) else 'Pessoa doadora' end,
    case when new.raw_user_meta_data->>'account_type'='ONG' then 'ONG' else 'Pessoa física' end);
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function private.handle_new_user();

-- Também atende contas criadas antes da instalação deste esquema.
insert into public.profiles(id,display_name,account_type)
select id,case when char_length(trim(raw_user_meta_data->>'display_name'))>=2 then left(trim(raw_user_meta_data->>'display_name'),80) else 'Pessoa doadora' end,
  case when raw_user_meta_data->>'account_type'='ONG' then 'ONG' else 'Pessoa física' end
from auth.users on conflict(id) do nothing;

create or replace function public.touch_donation()
returns trigger language plpgsql set search_path='' as $$
begin
  new.updated_at=now();
  if new.owner_id<>old.owner_id or new.id<>old.id then raise exception 'A propriedade do anúncio não pode ser alterada.'; end if;
  return new;
end;
$$;
drop trigger if exists touch_donation on public.donations;
create trigger touch_donation before update on public.donations for each row execute function public.touch_donation();

alter table public.profiles enable row level security;
alter table public.donations enable row level security;
alter table public.donation_contacts enable row level security;
revoke all on public.profiles,public.donations,public.donation_contacts from anon,authenticated;
grant select on public.profiles to authenticated;
grant update(display_name,account_type) on public.profiles to authenticated;
grant select,insert,update,delete on public.donations,public.donation_contacts to authenticated;

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using(true);
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update to authenticated using(id=(select auth.uid())) with check(id=(select auth.uid()));
drop policy if exists donations_read on public.donations;
create policy donations_read on public.donations for select to authenticated using(status='disponivel' or owner_id=(select auth.uid()));
drop policy if exists donations_insert_own on public.donations;
create policy donations_insert_own on public.donations for insert to authenticated with check(owner_id=(select auth.uid()));
drop policy if exists donations_update_own on public.donations;
create policy donations_update_own on public.donations for update to authenticated using(owner_id=(select auth.uid())) with check(owner_id=(select auth.uid()));
drop policy if exists donations_delete_own on public.donations;
create policy donations_delete_own on public.donations for delete to authenticated using(owner_id=(select auth.uid()));

drop policy if exists contacts_read on public.donation_contacts;
create policy contacts_read on public.donation_contacts for select to authenticated using(exists(
  select 1 from public.donations d where d.id=donation_id and (d.status='disponivel' or d.owner_id=(select auth.uid()))));
drop policy if exists contacts_insert_own on public.donation_contacts;
create policy contacts_insert_own on public.donation_contacts for insert to authenticated with check(exists(
  select 1 from public.donations d where d.id=donation_id and d.owner_id=(select auth.uid())));
drop policy if exists contacts_update_own on public.donation_contacts;
create policy contacts_update_own on public.donation_contacts for update to authenticated using(exists(
  select 1 from public.donations d where d.id=donation_id and d.owner_id=(select auth.uid()))) with check(exists(
  select 1 from public.donations d where d.id=donation_id and d.owner_id=(select auth.uid())));
drop policy if exists contacts_delete_own on public.donation_contacts;
create policy contacts_delete_own on public.donation_contacts for delete to authenticated using(exists(
  select 1 from public.donations d where d.id=donation_id and d.owner_id=(select auth.uid())));

-- Anúncio e contatos são confirmados juntos.
alter table public.donation_contacts add column if not exists email text;
alter table public.donation_contacts add column if not exists instagram_url text;
do $$ begin
  if not exists(select 1 from pg_constraint where conname='donation_contacts_email_valid' and conrelid='public.donation_contacts'::regclass) then
    alter table public.donation_contacts add constraint donation_contacts_email_valid check(
      email is null or (char_length(email) between 3 and 254 and email=btrim(email) and email !~ '[[:space:]<>]' and email ~ '^[^@]+@[^@]+\.[^@]+$'));
  end if;
  if not exists(select 1 from pg_constraint where conname='donation_contacts_instagram_valid' and conrelid='public.donation_contacts'::regclass) then
    alter table public.donation_contacts add constraint donation_contacts_instagram_valid check(
      instagram_url is null or instagram_url ~ '^https://www[.]instagram[.]com/[a-z0-9._]{1,30}/$');
  end if;
end $$;

-- Remove apenas a assinatura antiga para evitar ambiguidade na API.
-- Chamadas com os dez parâmetros antigos continuam aceitas pelos valores padrão.
drop function if exists public.save_donation(uuid,text,text,text,text,text,text,text[],numeric,numeric);
create or replace function public.save_donation(
  p_id uuid,p_title text,p_category text,p_description text,p_city text,p_state text,
  p_phone text,p_photo_paths text[],p_lat numeric default null,p_lon numeric default null,
  p_email text default null,p_instagram_url text default null
) returns uuid language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=auth.uid();
begin
  if v_owner is null then raise exception 'Entre na sua conta para publicar.'; end if;
  insert into public.donations(id,owner_id,title,category,description,city,state,photo_paths,approx_lat,approx_lon)
  values(p_id,v_owner,trim(p_title),p_category,trim(p_description),trim(p_city),p_state,p_photo_paths,p_lat,p_lon)
  on conflict(id) do update set title=excluded.title,category=excluded.category,description=excluded.description,
    city=excluded.city,state=excluded.state,photo_paths=excluded.photo_paths,approx_lat=excluded.approx_lat,approx_lon=excluded.approx_lon;
  insert into public.donation_contacts(donation_id,phone,email,instagram_url)
  values(p_id,p_phone,nullif(btrim(p_email),''),nullif(btrim(p_instagram_url),''))
  on conflict(donation_id) do update set phone=excluded.phone,email=excluded.email,instagram_url=excluded.instagram_url;
  return p_id;
end;
$$;
revoke all on function public.save_donation(uuid,text,text,text,text,text,text,text[],numeric,numeric,text,text) from public,anon;
grant execute on function public.save_donation(uuid,text,text,text,text,text,text,text[],numeric,numeric,text,text) to authenticated;

revoke all on function private.handle_new_user() from public,anon,authenticated;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('donation-photos','donation-photos',true,5242880,array['image/jpeg'])
on conflict(id) do update set public=excluded.public,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists donation_photos_insert_own on storage.objects;
create policy donation_photos_insert_own on storage.objects for insert to authenticated with check(
  bucket_id='donation-photos' and (storage.foldername(name))[1]=(select auth.uid())::text
  and name ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}/[0-9a-f-]{36}\.jpg$');
drop policy if exists donation_photos_read_own on storage.objects;
create policy donation_photos_read_own on storage.objects for select to authenticated using(
  bucket_id='donation-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists donation_photos_delete_own on storage.objects;
create policy donation_photos_delete_own on storage.objects for delete to authenticated using(
  bucket_id='donation-photos' and (storage.foldername(name))[1]=(select auth.uid())::text);

create table if not exists public.profile_contacts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  phone text not null check(phone ~ '^55(11|12|13|14|15|16|17|18|19|21|22|24|27|28|31|32|33|34|35|37|38|41|42|43|44|45|46|47|48|49|51|53|54|55|61|62|63|64|65|66|67|68|69|71|73|74|75|77|79|81|82|83|84|85|86|87|88|89|91|92|93|94|95|96|97|98|99)([2-5][0-9]{7}|9[0-9]{8})$'),
  email text check(email is null or (char_length(email) between 3 and 254 and email=btrim(email) and email !~ '[[:space:]<>]' and email ~ '^[^@]+@[^@]+\.[^@]+$')),
  instagram_url text check(instagram_url is null or (instagram_url ~ '^https://www\.instagram\.com/[a-z0-9._]{1,30}/$' and instagram_url !~ '/[.]' and instagram_url !~ '[.]/$' and instagram_url !~ '[.][.]'))
);
alter table public.profile_contacts enable row level security;
revoke all on public.profile_contacts from anon,authenticated;
grant select,insert,delete on public.profile_contacts to authenticated;
grant update(phone,email,instagram_url) on public.profile_contacts to authenticated;
drop policy if exists profile_contacts_own on public.profile_contacts;
create policy profile_contacts_own on public.profile_contacts for all to authenticated
  using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));

create or replace function private.handle_new_user()
returns trigger language plpgsql security definer set search_path='' as $$
begin
  if tg_table_schema<>'auth' or tg_table_name<>'users' or tg_op<>'INSERT' then raise exception 'Gatilho de cadastro inválido.'; end if;
  insert into public.profiles(id,display_name,account_type)
  values(new.id,case when char_length(trim(new.raw_user_meta_data->>'display_name'))>=2 then left(trim(new.raw_user_meta_data->>'display_name'),80) else 'Pessoa doadora' end,
    case when new.raw_user_meta_data->>'account_type'='ONG' then 'ONG' else 'Pessoa física' end);
  if nullif(btrim(new.raw_user_meta_data->>'contact_phone'),'') is not null then
    insert into public.profile_contacts(user_id,phone) values(new.id,new.raw_user_meta_data->>'contact_phone');
  end if;
  return new;
end;
$$;

create or replace function public.save_profile(p_name text,p_account_type text,p_phone text,p_email text default null,p_instagram_url text default null)
returns void language plpgsql security invoker set search_path='' as $$
declare actor uuid := (select auth.uid());
begin
  if actor is null then raise exception 'Entre na sua conta para atualizar o cadastro.'; end if;
  update public.profiles set display_name=btrim(p_name),account_type=p_account_type where id=actor;
  if not found then raise exception 'Perfil não encontrado.'; end if;
  insert into public.profile_contacts(user_id,phone,email,instagram_url)
  values(actor,p_phone,nullif(btrim(p_email),''),nullif(btrim(p_instagram_url),''))
  on conflict(user_id) do update set phone=excluded.phone,email=excluded.email,instagram_url=excluded.instagram_url;
end;
$$;
revoke all on function public.save_profile(text,text,text,text,text) from public,anon;
grant execute on function public.save_profile(text,text,text,text,text) to authenticated;

revoke all on function private.handle_new_user() from public,anon,authenticated;
commit;
