-- Atualização de uma base já criada pela versão anterior do ConectaSolidário.
-- Preserva anúncios, telefones, fotos e permissões existentes.
begin;
alter table public.donation_contacts add column if not exists email text;
alter table public.donation_contacts add column if not exists instagram_url text;
do $$ begin
  if not exists(select 1 from pg_constraint where conname='donation_contacts_email_valid' and conrelid='public.donation_contacts'::regclass) then
    alter table public.donation_contacts add constraint donation_contacts_email_valid check(
      email is null or (char_length(email) between 3 and 254 and email=btrim(email) and email !~ '[[:space:]<>]' and email ~ '^[^@]+@[^@]+\.[^@]+$'));
  end if;
  if not exists(select 1 from pg_constraint where conname='donation_contacts_instagram_valid' and conrelid='public.donation_contacts'::regclass) then
    alter table public.donation_contacts add constraint donation_contacts_instagram_valid check(
      instagram_url is null or instagram_url ~ '^https://www[.]instagram[.]com/[a-z0-9._]{1,30}/$');
  end if;
end $$;

-- Remove apenas a assinatura antiga para evitar ambiguidade na API.
-- Chamadas com os dez parâmetros antigos continuam aceitas pelos valores padrão.
drop function if exists public.save_donation(uuid,text,text,text,text,text,text,text[],numeric,numeric);
create or replace function public.save_donation(
  p_id uuid,p_title text,p_category text,p_description text,p_city text,p_state text,
  p_phone text,p_photo_paths text[],p_lat numeric default null,p_lon numeric default null,
  p_email text default null,p_instagram_url text default null
) returns uuid language plpgsql security invoker set search_path='' as $$
declare v_owner uuid:=auth.uid();
begin
  if v_owner is null then raise exception 'Entre na sua conta para publicar.'; end if;
  insert into public.donations(id,owner_id,title,category,description,city,state,photo_paths,approx_lat,approx_lon)
  values(p_id,v_owner,trim(p_title),p_category,trim(p_description),trim(p_city),p_state,p_photo_paths,p_lat,p_lon)
  on conflict(id) do update set title=excluded.title,category=excluded.category,description=excluded.description,
    city=excluded.city,state=excluded.state,photo_paths=excluded.photo_paths,approx_lat=excluded.approx_lat,approx_lon=excluded.approx_lon;
  insert into public.donation_contacts(donation_id,phone,email,instagram_url)
  values(p_id,p_phone,nullif(btrim(p_email),''),nullif(btrim(p_instagram_url),''))
  on conflict(donation_id) do update set phone=excluded.phone,email=excluded.email,instagram_url=excluded.instagram_url;
  return p_id;
end;
$$;
revoke all on function public.save_donation(uuid,text,text,text,text,text,text,text[],numeric,numeric,text,text) from public,anon;
grant execute on function public.save_donation(uuid,text,text,text,text,text,text,text[],numeric,numeric,text,text) to authenticated;
commit;
