-- Isola o gatilho do Auth fora da API pública. Preserva contas e anúncios.
begin;
create schema if not exists private;
revoke all on schema private from public,anon,authenticated;
-- auth.uid() pode estar vazio no serviço de cadastro. O dono vem de NEW.id
-- no gatilho de auth.users, nunca dos metadados editáveis do usuário.
create or replace function private.handle_new_user()
returns trigger language plpgsql security definer set search_path='' as $$
begin
  if tg_table_schema<>'auth' or tg_table_name<>'users' or tg_op<>'INSERT' then raise exception 'Gatilho de cadastro inválido.'; end if;
  insert into public.profiles(id,display_name,account_type)
  values(new.id,case when char_length(trim(new.raw_user_meta_data->>'display_name'))>=2 then left(trim(new.raw_user_meta_data->>'display_name'),80) else 'Pessoa doadora' end,
    case when new.raw_user_meta_data->>'account_type'='ONG' then 'ONG' else 'Pessoa física' end);
  if nullif(btrim(new.raw_user_meta_data->>'contact_phone'),'') is not null then
    insert into public.profile_contacts(user_id,phone) values(new.id,new.raw_user_meta_data->>'contact_phone');
  end if;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function private.handle_new_user();
revoke all on function private.handle_new_user() from public,anon,authenticated;
drop function if exists public.handle_new_user();
commit;
