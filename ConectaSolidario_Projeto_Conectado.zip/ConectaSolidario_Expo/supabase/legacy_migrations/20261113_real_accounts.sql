-- Aplicar depois de schema.sql/20261113_contacts.sql. Preserva contas e anúncios.
begin;
create table if not exists public.profile_contacts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  phone text not null check(phone ~ '^55(11|12|13|14|15|16|17|18|19|21|22|24|27|28|31|32|33|34|35|37|38|41|42|43|44|45|46|47|48|49|51|53|54|55|61|62|63|64|65|66|67|68|69|71|73|74|75|77|79|81|82|83|84|85|86|87|88|89|91|92|93|94|95|96|97|98|99)([2-5][0-9]{7}|9[0-9]{8})$'),
  email text check(email is null or (char_length(email) between 3 and 254 and email=btrim(email) and email !~ '[[:space:]<>]' and email ~ '^[^@]+@[^@]+\.[^@]+$')),
  instagram_url text check(instagram_url is null or (instagram_url ~ '^https://www\.instagram\.com/[a-z0-9._]{1,30}/$' and instagram_url !~ '/[.]' and instagram_url !~ '[.]/$' and instagram_url !~ '[.][.]'))
);
alter table public.profile_contacts enable row level security;
revoke all on public.profile_contacts from anon,authenticated;
grant select,insert,delete on public.profile_contacts to authenticated;
grant update(phone,email,instagram_url) on public.profile_contacts to authenticated;
drop policy if exists profile_contacts_own on public.profile_contacts;
create policy profile_contacts_own on public.profile_contacts for all to authenticated
  using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path='' as $$
begin
  insert into public.profiles(id,display_name,account_type)
  values(new.id,case when char_length(trim(new.raw_user_meta_data->>'display_name'))>=2 then left(trim(new.raw_user_meta_data->>'display_name'),80) else 'Pessoa doadora' end,
    case when new.raw_user_meta_data->>'account_type'='ONG' then 'ONG' else 'Pessoa física' end);
  if nullif(btrim(new.raw_user_meta_data->>'contact_phone'),'') is not null then
    insert into public.profile_contacts(user_id,phone) values(new.id,new.raw_user_meta_data->>'contact_phone');
  end if;
  return new;
end;
$$;

create or replace function public.save_profile(p_name text,p_account_type text,p_phone text,p_email text default null,p_instagram_url text default null)
returns void language plpgsql security invoker set search_path='' as $$
declare actor uuid := (select auth.uid());
begin
  if actor is null then raise exception 'Entre na sua conta para atualizar o cadastro.'; end if;
  update public.profiles set display_name=btrim(p_name),account_type=p_account_type where id=actor;
  if not found then raise exception 'Perfil não encontrado.'; end if;
  insert into public.profile_contacts(user_id,phone,email,instagram_url)
  values(actor,p_phone,nullif(btrim(p_email),''),nullif(btrim(p_instagram_url),''))
  on conflict(user_id) do update set phone=excluded.phone,email=excluded.email,instagram_url=excluded.instagram_url;
end;
$$;
revoke all on function public.save_profile(text,text,text,text,text) from public,anon;
grant execute on function public.save_profile(text,text,text,text,text) to authenticated;
commit;
